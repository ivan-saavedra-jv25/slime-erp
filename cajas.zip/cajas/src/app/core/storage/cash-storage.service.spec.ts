import { TestBed } from '@angular/core/testing';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { CashStorageService } from './cash-storage.service';
import { STORAGE_KEYS, STORAGE_PREFIX } from './storage-keys';

interface Registro {
  id: string;
  nombre: string;
  fechaCreacion?: Date;
}

describe('CashStorageService', () => {
  let storage: CashStorageService;

  beforeEach(() => {
    localStorage.clear();
    TestBed.configureTestingModule({});
    storage = TestBed.inject(CashStorageService);
  });

  it('devuelve [] cuando la clave no existe', () => {
    expect(storage.read(STORAGE_KEYS.registers)).toEqual([]);
  });

  it('hace round-trip de una colección', () => {
    const items: Registro[] = [
      { id: 'a', nombre: 'Caja A' },
      { id: 'b', nombre: 'Caja B' },
    ];
    storage.write(STORAGE_KEYS.registers, items);
    expect(storage.read<Registro>(STORAGE_KEYS.registers)).toEqual(items);
  });

  it('usa el prefijo del módulo para no chocar con otras apps', () => {
    storage.write(STORAGE_KEYS.registers, [{ id: 'a', nombre: 'Caja A' }]);
    expect(localStorage.getItem(STORAGE_PREFIX + STORAGE_KEYS.registers)).not.toBeNull();
    expect(localStorage.getItem(STORAGE_KEYS.registers)).toBeNull();
  });

  it('rehidrata las fechas ISO como objetos Date', () => {
    const fecha = new Date('2026-01-15T12:30:00.000Z');
    storage.write(STORAGE_KEYS.registers, [{ id: 'a', nombre: 'Caja A', fechaCreacion: fecha }]);

    const leido = storage.read<Registro>(STORAGE_KEYS.registers);
    expect(leido[0].fechaCreacion).toBeInstanceOf(Date);
    expect(leido[0].fechaCreacion?.getTime()).toBe(fecha.getTime());
  });

  it('devuelve [] si el JSON está corrupto en vez de reventar', () => {
    vi.spyOn(console, 'warn').mockImplementation(() => {});
    localStorage.setItem(STORAGE_PREFIX + STORAGE_KEYS.sessions, '{no es json');
    expect(storage.read(STORAGE_KEYS.sessions)).toEqual([]);
  });

  it('devuelve [] si el contenido no es un arreglo', () => {
    localStorage.setItem(STORAGE_PREFIX + STORAGE_KEYS.sessions, '{"id":"a"}');
    expect(storage.read(STORAGE_KEYS.sessions)).toEqual([]);
  });

  it('upsert inserta cuando el id no existe', () => {
    storage.upsert<Registro>(STORAGE_KEYS.registers, { id: 'a', nombre: 'Caja A' });
    expect(storage.read<Registro>(STORAGE_KEYS.registers)).toHaveLength(1);
  });

  it('upsert actualiza sin duplicar cuando el id ya existe', () => {
    storage.upsert<Registro>(STORAGE_KEYS.registers, { id: 'a', nombre: 'Caja A' });
    storage.upsert<Registro>(STORAGE_KEYS.registers, { id: 'a', nombre: 'Caja Renombrada' });

    const items = storage.read<Registro>(STORAGE_KEYS.registers);
    expect(items).toHaveLength(1);
    expect(items[0].nombre).toBe('Caja Renombrada');
  });

  it('append agrega siempre, aunque el id se repita (auditoría)', () => {
    storage.append<Registro>(STORAGE_KEYS.audits, { id: 'a', nombre: 'Evento' });
    storage.append<Registro>(STORAGE_KEYS.audits, { id: 'a', nombre: 'Evento' });
    expect(storage.read(STORAGE_KEYS.audits)).toHaveLength(2);
  });

  it('no propaga el error cuando LocalStorage rechaza la escritura', () => {
    vi.spyOn(console, 'error').mockImplementation(() => {});
    const setItem = vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
      throw new DOMException('QuotaExceededError');
    });

    expect(() => storage.write(STORAGE_KEYS.registers, [{ id: 'a', nombre: 'A' }])).not.toThrow();
    setItem.mockRestore();
  });
});
