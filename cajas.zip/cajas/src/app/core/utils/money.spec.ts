import { describe, expect, it } from 'vitest';
import { CashDifferenceStatus, CashMovement, CashMovementOrigin, CashMovementType } from '../models';
import {
  DENOMINATIONS,
  buildCashCount,
  buildCountItem,
  countTotal,
  difference,
  differenceStatus,
  emptyCountItems,
  expectedBalance,
  formatCLP,
  normalizeAmount,
  normalizeQuantity,
  totalEntradas,
  totalSalidas,
} from './money';

function movimiento(tipo: CashMovementType, monto: number): CashMovement {
  return {
    id: `mov_${monto}_${tipo}`,
    cajaId: 'caja_1',
    sesionCajaId: 'ses_1',
    tipo,
    origen: CashMovementOrigin.MANUAL,
    concepto: 'Test',
    monto,
    observacion: '',
    fecha: new Date('2026-01-01T10:00:00Z'),
    responsableId: 'usr_admin',
  };
}

describe('DENOMINATIONS', () => {
  it('cubre las denominaciones del peso chileno de mayor a menor', () => {
    expect([...DENOMINATIONS]).toEqual([20000, 10000, 5000, 2000, 1000, 500, 100, 50, 10]);
  });
});

describe('normalizeQuantity', () => {
  it('trunca decimales', () => {
    expect(normalizeQuantity(3.9)).toBe(3);
  });

  it('convierte negativos en 0 (regla 6)', () => {
    expect(normalizeQuantity(-5)).toBe(0);
  });

  it('devuelve 0 ante valores no numéricos', () => {
    expect(normalizeQuantity('')).toBe(0);
    expect(normalizeQuantity('abc')).toBe(0);
    expect(normalizeQuantity(null)).toBe(0);
  });

  it('acepta strings numéricos del input', () => {
    expect(normalizeQuantity('7')).toBe(7);
  });
});

describe('normalizeAmount', () => {
  it('no admite decimales: los montos son enteros CLP (reglas 11-12)', () => {
    expect(normalizeAmount(1500.75)).toBe(1500);
  });
});

describe('buildCountItem', () => {
  it('calcula el subtotal como denominación × cantidad', () => {
    expect(buildCountItem(20000, 2)).toEqual({ denomination: 20000, quantity: 2, subtotal: 40000 });
  });

  it('deja subtotal 0 cuando la cantidad es negativa', () => {
    expect(buildCountItem(5000, -3)).toEqual({ denomination: 5000, quantity: 0, subtotal: 0 });
  });
});

describe('countTotal', () => {
  it('suma Σ(denominación × cantidad) — ejemplo del spec §2', () => {
    const items = [
      buildCountItem(20000, 2),
      buildCountItem(10000, 0),
      buildCountItem(5000, 1),
    ];
    expect(countTotal(items)).toBe(45000);
  });

  it('un conteo vacío totaliza 0', () => {
    expect(countTotal(emptyCountItems())).toBe(0);
  });
});

describe('buildCashCount', () => {
  it('recalcula subtotales y total aunque lleguen corruptos', () => {
    const conteo = buildCashCount([{ denomination: 1000, quantity: 3, subtotal: 999999 }]);
    expect(conteo.items[0].subtotal).toBe(3000);
    expect(conteo.total).toBe(3000);
  });
});

describe('expectedBalance', () => {
  it('saldo inicial + entradas − salidas — ejemplo del spec §4', () => {
    const movimientos = [
      movimiento(CashMovementType.ENTRADA, 250000),
      movimiento(CashMovementType.SALIDA, 80000),
    ];
    expect(expectedBalance(100000, movimientos)).toBe(270000);
  });

  it('sin movimientos devuelve el saldo inicial', () => {
    expect(expectedBalance(45000, [])).toBe(45000);
  });

  it('totalEntradas y totalSalidas separan por tipo', () => {
    const movimientos = [
      movimiento(CashMovementType.ENTRADA, 1000),
      movimiento(CashMovementType.ENTRADA, 2000),
      movimiento(CashMovementType.SALIDA, 500),
    ];
    expect(totalEntradas(movimientos)).toBe(3000);
    expect(totalSalidas(movimientos)).toBe(500);
  });
});

describe('difference', () => {
  it('faltante: contado menor que esperado — ejemplo del spec §8', () => {
    expect(difference(156630, 155630)).toBe(-1000);
    expect(differenceStatus(-1000)).toBe(CashDifferenceStatus.FALTANTE);
  });

  it('sobrante: contado mayor que esperado', () => {
    expect(difference(100000, 101500)).toBe(1500);
    expect(differenceStatus(1500)).toBe(CashDifferenceStatus.SOBRANTE);
  });

  it('caja cuadrada cuando la diferencia es exactamente 0 (regla 8)', () => {
    expect(difference(270000, 270000)).toBe(0);
    expect(differenceStatus(0)).toBe(CashDifferenceStatus.CUADRADA);
  });

  it('no redondea diferencias pequeñas', () => {
    expect(difference(156630, 156620)).toBe(-10);
  });
});

describe('formatCLP', () => {
  it('formatea sin decimales con separador de miles', () => {
    expect(formatCLP(156630)).toBe('$156.630');
  });

  it('mantiene el signo en montos negativos', () => {
    expect(formatCLP(-1000)).toBe('-$1.000');
  });

  it('formatea el cero', () => {
    expect(formatCLP(0)).toBe('$0');
  });
});
