import { TestBed } from '@angular/core/testing';
import { beforeEach, describe, expect, it } from 'vitest';
import {
  AuditAction,
  CashCountItem,
  CashDifferenceStatus,
  CashMovementOrigin,
  CashRegisterStatus,
  CashRegisterType,
  CashSessionStatus,
} from '../models';
import { SeedService } from '../seed/seed.service';
import { CashStorageService } from '../storage/cash-storage.service';
import { STORAGE_KEYS } from '../storage/storage-keys';
import { buildCountItem } from '../utils/money';
import { BusinessRuleError } from './business-rule-error';
import { CajaFacade } from './caja-facade.service';
import { CashAuditService } from './cash-audit.service';
import { CashRegisterService } from './cash-register.service';
import { CashSessionService } from './cash-session.service';

/** Conteo de $45.000: 2 × $20.000 + 1 × $5.000. */
function conteo45000(): CashCountItem[] {
  return [buildCountItem(20000, 2), buildCountItem(5000, 1)];
}

describe('CajaFacade — flujo completo de caja', () => {
  let facade: CajaFacade;
  let registers: CashRegisterService;
  let sessions: CashSessionService;
  let audit: CashAuditService;
  let cajaId: string;

  beforeEach(() => {
    localStorage.clear();
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({});
    TestBed.inject(SeedService).seed();

    facade = TestBed.inject(CajaFacade);
    registers = TestBed.inject(CashRegisterService);
    sessions = TestBed.inject(CashSessionService);
    audit = TestBed.inject(CashAuditService);
    cajaId = registers.all()[0].id;
  });

  describe('datos iniciales (spec §19)', () => {
    it('crea la caja mock la primera vez', () => {
      const caja = registers.all()[0];
      expect(caja.nombre).toBe('Caja Sucursal Principal');
      expect(caja.tipo).toBe(CashRegisterType.SUCURSAL);
      expect(caja.estado).toBe(CashRegisterStatus.CERRADA);
    });

    it('registra CAJA_CREADA en la auditoría', () => {
      expect(audit.all().some((a) => a.accion === AuditAction.CAJA_CREADA)).toBe(true);
    });

    it('la semilla es idempotente', () => {
      TestBed.inject(SeedService).seed();
      expect(registers.all()).toHaveLength(1);
    });
  });

  describe('apertura (spec §2)', () => {
    it('crea la sesión con el saldo inicial calculado del conteo', () => {
      const sesion = facade.abrirCaja(cajaId, conteo45000());
      expect(sesion.saldoInicial).toBe(45000);
      expect(sesion.estado).toBe(CashSessionStatus.ABIERTA);
      expect(sesion.conteoInicial.total).toBe(45000);
    });

    it('cambia el estado de la caja a ABIERTA', () => {
      facade.abrirCaja(cajaId, conteo45000());
      expect(registers.byId(cajaId)?.estado).toBe(CashRegisterStatus.ABIERTA);
    });

    it('registra CAJA_ABIERTA en la auditoría', () => {
      facade.abrirCaja(cajaId, conteo45000());
      expect(audit.all().some((a) => a.accion === AuditAction.CAJA_ABIERTA)).toBe(true);
    });

    it('rechaza una segunda apertura de la misma caja (regla 1)', () => {
      facade.abrirCaja(cajaId, conteo45000());
      expect(() => facade.abrirCaja(cajaId, conteo45000())).toThrowError(BusinessRuleError);
    });
  });

  describe('movimientos (spec §5, §6)', () => {
    beforeEach(() => {
      facade.abrirCaja(cajaId, conteo45000());
    });

    it('una entrada aumenta el saldo esperado', () => {
      facade.registrarEntrada({ concepto: 'Ingreso de efectivo', monto: 250000 });
      expect(facade.saldoEsperado()).toBe(295000);
      expect(facade.totalEntradas()).toBe(250000);
    });

    it('una salida disminuye el saldo esperado', () => {
      facade.registrarEntrada({ concepto: 'Ingreso de efectivo', monto: 250000 });
      facade.registrarSalida({ concepto: 'Gasto', monto: 80000 });
      expect(facade.saldoEsperado()).toBe(215000);
      expect(facade.totalSalidas()).toBe(80000);
    });

    it('rechaza una salida mayor al saldo disponible (regla 5)', () => {
      expect(() => facade.registrarSalida({ concepto: 'Retiro', monto: 500000 })).toThrowError(
        /supera el saldo/i,
      );
      expect(facade.saldoEsperado()).toBe(45000);
    });

    it('rechaza montos no positivos (reglas 11-12)', () => {
      expect(() => facade.registrarEntrada({ concepto: 'Otro', monto: 0 })).toThrowError(
        BusinessRuleError,
      );
    });

    it('rechaza un concepto vacío', () => {
      expect(() => facade.registrarEntrada({ concepto: '  ', monto: 1000 })).toThrowError(
        BusinessRuleError,
      );
    });

    it('todo movimiento pertenece a la sesión y lleva fecha y responsable (reglas 9-10)', () => {
      const movimiento = facade.registrarEntrada({ concepto: 'Devolución', monto: 5000 });
      expect(movimiento.sesionCajaId).toBe(facade.sesionActiva()!.id);
      expect(movimiento.cajaId).toBe(cajaId);
      expect(movimiento.responsableId).toBeTruthy();
      expect(movimiento.fecha).toBeInstanceOf(Date);
    });

    it('el origen es MANUAL en esta versión (spec §20)', () => {
      const movimiento = facade.registrarEntrada({ concepto: 'Rendición', monto: 1000 });
      expect(movimiento.origen).toBe(CashMovementOrigin.MANUAL);
    });

    it('audita cada entrada y cada salida', () => {
      facade.registrarEntrada({ concepto: 'Ingreso de efectivo', monto: 10000 });
      facade.registrarSalida({ concepto: 'Gasto', monto: 2000 });
      const acciones = audit.all().map((a) => a.accion);
      expect(acciones).toContain(AuditAction.ENTRADA_REGISTRADA);
      expect(acciones).toContain(AuditAction.SALIDA_REGISTRADA);
    });
  });

  describe('arqueo (spec §8)', () => {
    beforeEach(() => {
      facade.abrirCaja(cajaId, conteo45000());
    });

    it('detecta un faltante sin redondear', () => {
      facade.registrarArqueo([buildCountItem(20000, 2), buildCountItem(1000, 4)]);
      expect(facade.diferenciaArqueo()).toBe(-1000);
      expect(facade.estadoDiferenciaArqueo()).toBe(CashDifferenceStatus.FALTANTE);
    });

    it('detecta caja cuadrada', () => {
      facade.registrarArqueo(conteo45000());
      expect(facade.diferenciaArqueo()).toBe(0);
      expect(facade.estadoDiferenciaArqueo()).toBe(CashDifferenceStatus.CUADRADA);
    });

    it('detecta un sobrante', () => {
      facade.registrarArqueo([buildCountItem(20000, 3)]);
      expect(facade.diferenciaArqueo()).toBe(15000);
      expect(facade.estadoDiferenciaArqueo()).toBe(CashDifferenceStatus.SOBRANTE);
    });

    it('registra ARQUEO_REALIZADO en la auditoría', () => {
      facade.registrarArqueo(conteo45000());
      expect(audit.all().some((a) => a.accion === AuditAction.ARQUEO_REALIZADO)).toBe(true);
    });
  });

  describe('cierre (spec §9, §10)', () => {
    beforeEach(() => {
      facade.abrirCaja(cajaId, conteo45000());
      facade.registrarEntrada({ concepto: 'Ingreso de efectivo', monto: 250000 });
      facade.registrarSalida({ concepto: 'Gasto', monto: 80000 });
    });

    it('guarda esperado, contado y diferencia', () => {
      // Esperado 215.000, contado 214.000 → faltante de 1.000.
      const cerrada = facade.cerrarCaja({
        items: [buildCountItem(20000, 10), buildCountItem(10000, 1), buildCountItem(2000, 2)],
        observacionCierre: 'Faltante detectado en el turno',
      });

      expect(cerrada.saldoEsperado).toBe(215000);
      expect(cerrada.saldoContado).toBe(214000);
      expect(cerrada.diferencia).toBe(-1000);
      expect(cerrada.observacionCierre).toBe('Faltante detectado en el turno');
    });

    it('conserva la diferencia aunque sea cero (regla 8)', () => {
      const cerrada = facade.cerrarCaja({ items: [buildCountItem(20000, 10), buildCountItem(5000, 3)] });
      expect(cerrada.diferencia).toBe(0);
      expect(cerrada.diferencia).not.toBeNull();
    });

    it('no bloquea el cierre con diferencia (spec §10)', () => {
      expect(() => facade.cerrarCaja({ items: [buildCountItem(1000, 1)] })).not.toThrow();
    });

    it('cierra la sesión y la caja', () => {
      const cerrada = facade.cerrarCaja({ items: conteo45000() });
      expect(cerrada.estado).toBe(CashSessionStatus.CERRADA);
      expect(cerrada.fechaCierre).toBeInstanceOf(Date);
      expect(registers.byId(cajaId)?.estado).toBe(CashRegisterStatus.CERRADA);
    });

    it('exige conteo final (regla 3)', () => {
      expect(() => facade.cerrarCaja({ items: [] })).toThrowError(/conteo final/i);
    });

    it('reutiliza el conteo del arqueo si no se pasa uno nuevo', () => {
      facade.registrarArqueo([buildCountItem(20000, 10), buildCountItem(10000, 1), buildCountItem(5000, 1)]);
      const cerrada = facade.cerrarCaja({});
      expect(cerrada.saldoContado).toBe(215000);
      expect(cerrada.diferencia).toBe(0);
    });

    it('una sesión cerrada no admite nuevos movimientos (reglas 2 y 4)', () => {
      facade.cerrarCaja({ items: conteo45000() });
      expect(() => facade.registrarEntrada({ concepto: 'Otro', monto: 1000 })).toThrowError(
        /no hay una sesión/i,
      );
    });

    it('una sesión cerrada no puede volver a cerrarse', () => {
      const cerrada = facade.cerrarCaja({ items: conteo45000() });
      expect(() =>
        sessions.close(cerrada.id, { saldoEsperado: 0, conteoFinal: cerrada.conteoFinal! }),
      ).toThrowError(/no puede modificarse/i);
    });

    it('registra CAJA_CERRADA en la auditoría', () => {
      facade.cerrarCaja({ items: conteo45000() });
      expect(audit.all().some((a) => a.accion === AuditAction.CAJA_CERRADA)).toBe(true);
    });

    it('permite reabrir la caja en una sesión nueva y conserva el historial', () => {
      facade.cerrarCaja({ items: conteo45000() });
      facade.abrirCaja(cajaId, [buildCountItem(10000, 1)]);
      expect(facade.historial()).toHaveLength(2);
      expect(facade.saldoEsperado()).toBe(10000);
    });
  });

  describe('persistencia en LocalStorage (spec §12)', () => {
    it('escribe las cuatro colecciones tras un ciclo completo', () => {
      facade.abrirCaja(cajaId, conteo45000());
      facade.registrarEntrada({ concepto: 'Ingreso de efectivo', monto: 10000 });
      facade.cerrarCaja({ items: conteo45000() });

      const storage = TestBed.inject(CashStorageService);
      expect(storage.read(STORAGE_KEYS.registers)).toHaveLength(1);
      expect(storage.read(STORAGE_KEYS.sessions)).toHaveLength(1);
      expect(storage.read(STORAGE_KEYS.movements)).toHaveLength(1);
      expect(storage.read(STORAGE_KEYS.audits).length).toBeGreaterThanOrEqual(4);
    });

    it('los datos sobreviven a una recarga de la aplicación', () => {
      facade.abrirCaja(cajaId, conteo45000());
      facade.registrarEntrada({ concepto: 'Ingreso de efectivo', monto: 250000 });

      // Simula el F5: instancias nuevas leyendo el mismo LocalStorage.
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({});
      const recargado = TestBed.inject(CajaFacade);

      expect(recargado.hayCajaAbierta()).toBe(true);
      expect(recargado.saldoEsperado()).toBe(295000);
      expect(recargado.movimientosSesion()).toHaveLength(1);
    });

    it('la auditoría nunca se elimina (spec §15)', () => {
      facade.abrirCaja(cajaId, conteo45000());
      const antes = audit.all().length;
      facade.cerrarCaja({ items: conteo45000() });
      expect(audit.all().length).toBeGreaterThan(antes);
    });
  });
});
