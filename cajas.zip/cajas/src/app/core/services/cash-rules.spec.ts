import { describe, expect, it } from 'vitest';
import {
  CashCount,
  CashRegister,
  CashRegisterStatus,
  CashRegisterType,
  CashSession,
  CashSessionStatus,
} from '../models';
import { buildCashCount } from '../utils/money';
import { BusinessRuleError } from './business-rule-error';
import {
  assertCantidadValida,
  assertCanClose,
  assertCanOpen,
  assertCanRegisterMovement,
  assertConceptoValido,
  assertMontoValido,
  assertMutable,
  assertSalidaPermitida,
} from './cash-rules';

function caja(overrides: Partial<CashRegister> = {}): CashRegister {
  return {
    id: 'caja_1',
    nombre: 'Caja Sucursal Principal',
    tipo: CashRegisterType.SUCURSAL,
    sucursalId: 'suc_principal',
    responsableId: 'usr_admin',
    estado: CashRegisterStatus.CERRADA,
    saldoInicial: 0,
    saldoActual: 0,
    fechaCreacion: new Date('2026-01-01T09:00:00Z'),
    fechaActualizacion: new Date('2026-01-01T09:00:00Z'),
    ...overrides,
  };
}

function sesion(overrides: Partial<CashSession> = {}): CashSession {
  const conteo: CashCount = buildCashCount([{ denomination: 20000, quantity: 2, subtotal: 40000 }]);
  return {
    id: 'ses_1',
    cajaId: 'caja_1',
    responsableId: 'usr_admin',
    fechaApertura: new Date('2026-01-01T09:00:00Z'),
    fechaCierre: null,
    saldoInicial: 40000,
    saldoEsperado: 40000,
    saldoContado: null,
    diferencia: null,
    estado: CashSessionStatus.ABIERTA,
    conteoInicial: conteo,
    conteoFinal: null,
    ...overrides,
  };
}

describe('Regla 1 — no se puede abrir una caja ya abierta', () => {
  it('permite abrir una caja cerrada sin sesiones activas', () => {
    expect(() => assertCanOpen(caja(), [])).not.toThrow();
  });

  it('rechaza una caja cuyo estado ya es ABIERTA', () => {
    expect(() => assertCanOpen(caja({ estado: CashRegisterStatus.ABIERTA }), [])).toThrowError(
      BusinessRuleError,
    );
  });

  it('rechaza si existe una sesión abierta sin cerrar', () => {
    expect(() => assertCanOpen(caja(), [sesion()])).toThrowError(/sesión abierta/i);
  });

  it('ignora sesiones ya cerradas de la misma caja', () => {
    const cerrada = sesion({ estado: CashSessionStatus.CERRADA });
    expect(() => assertCanOpen(caja(), [cerrada])).not.toThrow();
  });
});

describe('Regla 2 — no se registran movimientos en una caja cerrada', () => {
  it('acepta una sesión abierta', () => {
    expect(() => assertCanRegisterMovement(sesion())).not.toThrow();
  });

  it('rechaza cuando no hay sesión', () => {
    expect(() => assertCanRegisterMovement(null)).toThrowError(/no hay una sesión/i);
  });

  it('rechaza una sesión cerrada', () => {
    expect(() =>
      assertCanRegisterMovement(sesion({ estado: CashSessionStatus.CERRADA })),
    ).toThrowError(/cerrada/i);
  });
});

describe('Regla 3 — no se cierra sin conteo final', () => {
  it('acepta cuando hay conteo final', () => {
    const conteo = buildCashCount([{ denomination: 10000, quantity: 1, subtotal: 10000 }]);
    expect(() => assertCanClose(sesion(), conteo)).not.toThrow();
  });

  it('rechaza cuando el conteo final es null', () => {
    expect(() => assertCanClose(sesion(), null)).toThrowError(/conteo final/i);
  });

  it('rechaza un conteo final sin líneas', () => {
    const vacio: CashCount = { items: [], total: 0, fecha: new Date() };
    expect(() => assertCanClose(sesion(), vacio)).toThrowError(/conteo final/i);
  });
});

describe('Regla 4 — una sesión cerrada no puede modificarse', () => {
  it('permite mutar una sesión abierta', () => {
    expect(() => assertMutable(sesion())).not.toThrow();
  });

  it('bloquea la mutación de una sesión cerrada', () => {
    expect(() => assertMutable(sesion({ estado: CashSessionStatus.CERRADA }))).toThrowError(
      /no puede modificarse/i,
    );
  });
});

describe('Regla 5 — una salida no puede superar el saldo disponible', () => {
  it('permite una salida menor al saldo', () => {
    expect(() => assertSalidaPermitida(80000, 295000)).not.toThrow();
  });

  it('permite vaciar la caja exactamente', () => {
    expect(() => assertSalidaPermitida(295000, 295000)).not.toThrow();
  });

  it('rechaza una salida que dejaría el saldo negativo', () => {
    expect(() => assertSalidaPermitida(500000, 295000)).toThrowError(/supera el saldo/i);
  });
});

describe('Regla 6 — las cantidades no pueden ser negativas', () => {
  it('acepta cantidades positivas', () => {
    expect(assertCantidadValida(4)).toBe(4);
  });

  it('acepta cero', () => {
    expect(assertCantidadValida(0)).toBe(0);
  });

  it('rechaza cantidades negativas', () => {
    expect(() => assertCantidadValida(-1)).toThrowError(/negativa/i);
  });
});

describe('Reglas 11-12 — montos enteros en pesos, sin decimales', () => {
  it('acepta un entero positivo', () => {
    expect(assertMontoValido(250000)).toBe(250000);
  });

  it('trunca los decimales en vez de aceptarlos', () => {
    expect(assertMontoValido(1500.99)).toBe(1500);
  });

  it('rechaza cero', () => {
    expect(() => assertMontoValido(0)).toThrowError(/mayor que cero/i);
  });

  it('rechaza montos negativos', () => {
    expect(() => assertMontoValido(-100)).toThrowError(BusinessRuleError);
  });
});

describe('Concepto obligatorio', () => {
  it('normaliza espacios sobrantes', () => {
    expect(assertConceptoValido('  Gasto  ')).toBe('Gasto');
  });

  it('rechaza un concepto vacío', () => {
    expect(() => assertConceptoValido('   ')).toThrowError(/concepto/i);
  });
});
