import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { CashRegisterStatus } from './core/models';
import { nombreSucursal, nombreUsuario } from './core/seed/mock-data';
import { CajaFacade } from './core/services/caja-facade.service';
import { ClpPipe } from './shared/pipes/clp.pipe';

/** Shell de la aplicación: navegación lateral + estado de caja siempre visible (spec §18). */
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, ClpPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.scss',
})
export class App {
  private readonly facade = inject(CajaFacade);

  readonly caja = this.facade.cajaActual;
  readonly sesion = this.facade.sesionActiva;
  readonly abierta = this.facade.hayCajaAbierta;
  readonly saldoEsperado = this.facade.saldoEsperado;

  readonly estado = computed(() =>
    this.abierta() ? CashRegisterStatus.ABIERTA : CashRegisterStatus.CERRADA,
  );

  readonly responsable = computed(() => {
    const caja = this.caja();
    return caja ? nombreUsuario(caja.responsableId) : '—';
  });

  readonly sucursal = computed(() => {
    const caja = this.caja();
    return caja ? nombreSucursal(caja.sucursalId) : '—';
  });

  /** Enlaces que requieren sesión abierta: se deshabilitan visualmente con la caja cerrada. */
  readonly navOperacion = [
    { path: '/caja/movimientos', label: 'Movimientos' },
    { path: '/caja/entradas', label: 'Entradas' },
    { path: '/caja/salidas', label: 'Salidas' },
    { path: '/caja/arqueo', label: 'Arqueo' },
    { path: '/caja/cierre', label: 'Cierre' },
  ];
}
