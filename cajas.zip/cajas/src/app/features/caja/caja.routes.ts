import { Routes } from '@angular/router';
import { sesionAbiertaGuard, sinSesionGuard } from '../../core/guards/caja.guards';

/** Únicas vistas del módulo (spec §18). Nada de Ventas, Compras, Inventario ni DTE. */
export const CAJA_ROUTES: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'resumen' },
  {
    path: 'resumen',
    title: 'Resumen de Caja',
    loadComponent: () => import('./resumen/resumen').then((m) => m.ResumenComponent),
  },
  {
    path: 'apertura',
    title: 'Apertura de Caja',
    canActivate: [sinSesionGuard],
    loadComponent: () => import('./apertura/apertura').then((m) => m.AperturaComponent),
  },
  {
    path: 'movimientos',
    title: 'Movimientos de Caja',
    canActivate: [sesionAbiertaGuard],
    loadComponent: () => import('./movimientos/movimientos').then((m) => m.MovimientosComponent),
  },
  {
    path: 'entradas',
    title: 'Entradas',
    canActivate: [sesionAbiertaGuard],
    loadComponent: () => import('./entradas/entradas').then((m) => m.EntradasComponent),
  },
  {
    path: 'salidas',
    title: 'Salidas',
    canActivate: [sesionAbiertaGuard],
    loadComponent: () => import('./salidas/salidas').then((m) => m.SalidasComponent),
  },
  {
    path: 'arqueo',
    title: 'Arqueo',
    canActivate: [sesionAbiertaGuard],
    loadComponent: () => import('./arqueo/arqueo').then((m) => m.ArqueoComponent),
  },
  {
    path: 'cierre',
    title: 'Cierre de Caja',
    canActivate: [sesionAbiertaGuard],
    loadComponent: () => import('./cierre/cierre').then((m) => m.CierreComponent),
  },
  {
    path: 'historial',
    title: 'Historial',
    loadComponent: () => import('./historial/historial').then((m) => m.HistorialComponent),
  },
];
