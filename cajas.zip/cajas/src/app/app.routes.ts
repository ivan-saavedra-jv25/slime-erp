import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'caja/resumen' },
  {
    path: 'caja',
    loadChildren: () => import('./features/caja/caja.routes').then((m) => m.CAJA_ROUTES),
  },
  { path: '**', redirectTo: 'caja/resumen' },
];
