/**
 * Setup global de los tests.
 *
 * Node 25 expone un `localStorage` global incompleto (un objeto sin métodos) que
 * tapa el de jsdom, así que `localStorage.setItem` no existe dentro de los tests.
 * Instalamos una implementación en memoria conforme a la interfaz Storage para
 * que CashStorageService se ejercite con su código real.
 */
class InMemoryStorage implements Storage {
  private data = new Map<string, string>();

  get length(): number {
    return this.data.size;
  }

  clear(): void {
    this.data.clear();
  }

  getItem(key: string): string | null {
    return this.data.get(key) ?? null;
  }

  key(index: number): string | null {
    return [...this.data.keys()][index] ?? null;
  }

  removeItem(key: string): void {
    this.data.delete(key);
  }

  setItem(key: string, value: string): void {
    this.data.set(key, String(value));
  }
}

const actual = (globalThis as { localStorage?: unknown }).localStorage;
const usable = !!actual && typeof (actual as Storage).setItem === 'function';

if (!usable) {
  const storage = new InMemoryStorage();
  Object.defineProperty(globalThis, 'localStorage', {
    value: storage,
    configurable: true,
    writable: true,
  });
  if (typeof window !== 'undefined') {
    Object.defineProperty(window, 'localStorage', {
      value: storage,
      configurable: true,
      writable: true,
    });
  }
}
