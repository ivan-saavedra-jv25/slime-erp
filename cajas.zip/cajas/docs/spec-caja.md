# Prompt — Sistema de Apertura y Cierre de Caja

Construye un módulo independiente de **Apertura y Cierre de Caja** utilizando **Angular** y exclusivamente **LocalStorage** como persistencia.

## Objetivo

Crear un sistema funcional para administrar cajas de efectivo, permitiendo:

- Apertura de caja.
- Conteo de efectivo mediante billetes y monedas.
- Registro de entradas de dinero.
- Registro de salidas de dinero.
- Visualización del saldo esperado.
- Arqueo de caja.
- Cierre de caja.
- Comparación entre saldo esperado y efectivo contado.
- Detección de diferencias.
- Historial de aperturas y cierres.
- Historial de movimientos.
- Auditoría básica.

**IMPORTANTE:** No implementar ningún módulo de Ventas, POS, Compras, Clientes, Productos, Inventario ni DTE.

El módulo debe funcionar de forma completamente independiente. Las entradas y salidas serán registradas manualmente mediante conceptos.

---

# 1. Arquitectura de Caja

La aplicación debe manejar una entidad `Caja`.

Cada caja debe tener:

- `id`
- `nombre`
- `tipo`
- `sucursalId`
- `responsableId`
- `estado`
- `saldoInicial`
- `saldoActual`
- `fechaCreacion`
- `fechaActualizacion`

Tipos de caja:

```text
SUCURSAL
VENDEDOR
POS
```

Estados:

```text
ABIERTA
CERRADA
```

Para esta primera versión no es necesario implementar autenticación real.

Utilizar datos mock para usuario y sucursal.

---

# 2. Apertura de Caja

Crear una pantalla específica:

**Apertura de Caja**

Antes de abrir una caja se debe verificar que no exista una apertura activa.

La pantalla debe mostrar:

### Información

- Caja
- Responsable
- Sucursal
- Fecha
- Hora

### Conteo de efectivo

Crear una tabla para billetes y monedas.

Denominaciones:

```text
$20.000
$10.000
$5.000
$2.000
$1.000
$500
$100
$50
$10
```

Columnas:

| Denominación | Cantidad | Subtotal |
|---|---:|---:|

La persona solamente debe ingresar la **cantidad física** de cada denominación.

Ejemplo:

```text
$20.000 × 2 = $40.000
$10.000 × 0 = $0
$5.000 × 1 = $5.000
```

El subtotal debe calcularse automáticamente:

```text
subtotal = denominacion × cantidad
```

Y al final:

```text
TOTAL EFECTIVO
```

El usuario nunca debería tener que escribir manualmente el monto total.

### Botón

**Abrir Caja**

Al confirmar:

1. Crear una sesión de caja.
2. Guardar el conteo inicial.
3. Calcular el saldo inicial.
4. Cambiar estado de la caja a `ABIERTA`.
5. Registrar la apertura en el historial.
6. Guardar todo en LocalStorage.

---

# 3. Sesión de Caja

Separar conceptualmente:

```text
Caja
```

de:

```text
Sesión de Caja
```

Una caja puede tener muchas sesiones históricas.

Una sesión representa:

```text
Apertura → Movimientos → Arqueo → Cierre
```

La sesión debe contener:

- `id`
- `cajaId`
- `responsableId`
- `fechaApertura`
- `fechaCierre`
- `saldoInicial`
- `saldoEsperado`
- `saldoContado`
- `diferencia`
- `estado`
- `conteoInicial`
- `conteoFinal`

---

# 4. Dashboard de Caja Abierta

Cuando una caja está abierta, mostrar un dashboard sencillo.

### Resumen

```text
Saldo inicial
$100.000
```

```text
Entradas
+$250.000
```

```text
Salidas
-$80.000
```

```text
Saldo esperado
$270.000
```

Mostrar también:

- Cantidad de movimientos.
- Última entrada.
- Última salida.
- Hora de apertura.
- Responsable.
- Estado de caja.

---

# 5. Entradas de Dinero

Crear una sección:

**Entradas**

Permitir registrar manualmente ingresos de efectivo.

Formulario:

- Concepto
- Monto
- Observación
- Fecha
- Responsable

Conceptos iniciales:

```text
Ingreso de efectivo
Devolución
Rendición
Transferencia recibida
Ajuste positivo
Otro
```

El sistema debe generar automáticamente:

- `id`
- `tipo = ENTRADA`
- `monto`
- `fecha`
- `usuario`
- `cajaId`
- `sesionCajaId`

Una entrada aumenta el saldo esperado.

---

# 6. Salidas de Dinero

Crear una sección:

**Salidas**

Formulario:

- Concepto
- Monto
- Observación
- Fecha
- Responsable

Conceptos iniciales:

```text
Pago a proveedor
Compra
Gasto
Entrega de efectivo
Transferencia enviada
Retiro
Ajuste negativo
Otro
```

Una salida disminuye el saldo esperado.

Antes de registrar una salida validar:

```text
monto <= saldo disponible
```

No permitir que la caja quede con saldo esperado negativo.

---

# 7. Movimientos

Crear una pantalla:

**Movimientos de Caja**

Mostrar todos los movimientos de la sesión actual.

Columnas:

| Fecha | Tipo | Concepto | Monto | Responsable |
|---|---|---|---:|---|

Utilizar:

- Entrada
- Salida

Permitir filtros por:

- Tipo
- Concepto
- Fecha

Mostrar al final:

```text
Total entradas
Total salidas
Saldo inicial
Saldo esperado
```

---

# 8. Arqueo de Caja

Crear una pantalla:

**Arqueo**

El objetivo es contar físicamente el dinero existente.

Utilizar exactamente el mismo componente de conteo de billetes y monedas utilizado en la apertura.

Ejemplo:

```text
$20.000 × 5 = $100.000
$10.000 × 4 = $40.000
$5.000 × 2 = $10.000
...
```

Calcular:

```text
Efectivo contado
```

Luego comparar:

```text
Saldo esperado
-
Efectivo contado
=
Diferencia
```

Ejemplo:

```text
Saldo esperado:    $156.630
Efectivo contado:  $155.630
Diferencia:         -$1.000
```

Mostrar claramente:

### Caja cuadrada

Cuando:

```text
diferencia === 0
```

### Sobrante

Cuando:

```text
diferencia > 0
```

### Faltante

Cuando:

```text
diferencia < 0
```

No redondear ni ocultar diferencias.

---

# 9. Cierre de Caja

El cierre debe seguir este flujo:

```text
Caja abierta
     ↓
Revisión de movimientos
     ↓
Arqueo
     ↓
Conteo de efectivo
     ↓
Comparación
     ↓
Confirmación
     ↓
Caja cerrada
```

Al cerrar:

Guardar:

- Fecha/hora de cierre.
- Saldo esperado.
- Saldo contado.
- Diferencia.
- Conteo final.
- Responsable.

Cambiar sesión a:

```text
CERRADA
```

Y la caja a:

```text
CERRADA
```

Una sesión cerrada no debe poder modificarse.

---

# 10. Diferencias de Caja

Si existe diferencia, mostrar un mensaje claro.

Ejemplo:

```text
⚠ Diferencia de caja

Saldo esperado: $156.630
Efectivo contado: $155.630

Faltante: $1.000
```

No bloquear obligatoriamente el cierre en esta primera versión.

Permitir cerrar, pero registrar la diferencia en la auditoría.

Agregar un campo:

```text
observacionCierre
```

para explicar la diferencia.

---

# 11. Historial de Cajas

Crear una sección:

**Historial**

Mostrar todas las sesiones anteriores.

Columnas:

| Fecha | Caja | Responsable | Apertura | Cierre | Esperado | Contado | Diferencia | Estado |
|---|---|---|---:|---:|---:|---:|---:|---|

Permitir abrir el detalle de una sesión cerrada.

El detalle debe mostrar:

### Apertura

Conteo completo de billetes y monedas.

### Movimientos

Todas las entradas y salidas.

### Cierre

Conteo completo de billetes y monedas.

### Resultado

```text
Saldo esperado
Saldo contado
Diferencia
```

---

# 12. LocalStorage

No utilizar backend.

Crear un servicio:

```text
CashStorageService
```

Utilizar LocalStorage para almacenar:

```text
cash_registers
cash_sessions
cash_movements
cash_audits
```

Crear servicios separados:

```text
CashRegisterService
CashSessionService
CashMovementService
CashAuditService
```

No acceder directamente a LocalStorage desde los componentes.

Toda persistencia debe pasar por los servicios.

---

# 13. Modelos TypeScript

Crear interfaces/enums bien definidos.

Por ejemplo:

```typescript
enum CashRegisterType {
  SUCURSAL = 'SUCURSAL',
  VENDEDOR = 'VENDEDOR',
  POS = 'POS'
}

enum CashRegisterStatus {
  ABIERTA = 'ABIERTA',
  CERRADA = 'CERRADA'
}

enum CashMovementType {
  ENTRADA = 'ENTRADA',
  SALIDA = 'SALIDA'
}
```

Crear interfaces para:

```text
CashRegister
CashSession
CashMovement
CashCount
CashCountItem
CashAudit
```

---

# 14. Componente reutilizable de conteo

Crear un componente:

```text
CashDenominationCounterComponent
```

Debe recibir las denominaciones y permitir introducir cantidades.

Debe devolver:

```typescript
{
  denomination: number;
  quantity: number;
  subtotal: number;
}
```

El componente debe calcular:

```text
total = Σ(denomination × quantity)
```

Debe utilizarse tanto para:

```text
Apertura
Arqueo
Cierre
```

No duplicar la lógica.

---

# 15. Auditoría

Registrar acciones importantes:

```text
CAJA_CREADA
CAJA_ABIERTA
ENTRADA_REGISTRADA
SALIDA_REGISTRADA
ARQUEO_REALIZADO
CAJA_CERRADA
```

Cada registro:

- Fecha
- Usuario
- Acción
- Caja
- Sesión
- Descripción

No eliminar registros de auditoría.

---

# 16. Reglas de negocio

Implementar como mínimo:

1. No se puede abrir una caja que ya está abierta.
2. No se puede registrar movimientos en una caja cerrada.
3. No se puede cerrar una caja sin realizar el conteo final.
4. Una sesión cerrada no puede modificarse.
5. Una salida no puede superar el saldo disponible.
6. Las cantidades de billetes/monedas no pueden ser negativas.
7. El total de efectivo siempre debe calcularse automáticamente.
8. La diferencia debe conservarse incluso si es cero.
9. Todos los movimientos deben pertenecer a una sesión.
10. Todos los movimientos deben registrar fecha y responsable.
11. Los montos deben manejarse como números enteros en pesos chilenos.
12. No utilizar valores monetarios con decimales.

---

# 17. UI/UX

Crear una interfaz empresarial, limpia y moderna.

Priorizar:

- Claridad.
- Lectura rápida.
- Totales visibles.
- Formularios simples.
- Tablas ordenadas.
- Estados visuales claros.

El conteo de efectivo debe ser especialmente sencillo.

La persona debe pensar únicamente:

> "Tengo 2 billetes de $20.000"

y escribir:

```text
Cantidad: 2
```

El sistema debe encargarse de todo lo demás.

---

# 18. Navegación

Crear solamente estas vistas:

```text
Caja
├── Resumen
├── Apertura
├── Movimientos
├── Entradas
├── Salidas
├── Arqueo
├── Cierre
└── Historial
```

No crear vistas relacionadas con:

- Ventas
- Compras
- Clientes
- Productos
- Inventario
- DTE
- Facturación

---

# 19. Datos iniciales

Al iniciar la aplicación por primera vez, crear automáticamente datos mock:

### Caja

```text
Caja Sucursal Principal
Tipo: SUCURSAL
Estado: CERRADA
```

### Usuario

```text
Administrador
```

### Sucursal

```text
Sucursal Principal
```

No utilizar backend ni API.

---

# 20. Preparación para futuras integraciones

Aunque actualmente todo sea manual, diseñar el sistema para que posteriormente pueda recibir movimientos externos.

Por ejemplo:

```text
CashMovement
```

debe poder identificar posteriormente el origen:

```text
MANUAL
VENTA
COMPRA
PAGO
COBRO
TRANSFERENCIA
RENDICION
```

Pero en esta versión solamente implementar:

```text
MANUAL
```

No implementar todavía las integraciones.

---

# Resultado esperado

El resultado debe ser un **módulo de Caja completamente funcional**, independiente de cualquier módulo comercial.

Flujo principal:

```text
CREAR CAJA
    ↓
APERTURA
    ↓
CONTEO DE BILLETES/MONEDAS
    ↓
CAJA ABIERTA
    ↓
ENTRADAS / SALIDAS
    ↓
ARQUEO
    ↓
CONTEO FINAL
    ↓
COMPARACIÓN
    ↓
CIERRE
    ↓
HISTORIAL
```

Toda la información debe persistir mediante LocalStorage para que al recargar la aplicación los datos permanezcan.

La implementación debe ser modular, tipada, reutilizable y preparada para que posteriormente pueda integrarse con el resto del ERP sin tener que rehacer el módulo de Caja.