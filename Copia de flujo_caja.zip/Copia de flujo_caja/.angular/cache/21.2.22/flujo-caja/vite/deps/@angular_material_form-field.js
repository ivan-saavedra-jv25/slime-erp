import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-U72MR4SI.js";
import "./chunk-TU7LXIIH.js";
import "./chunk-MOIWW6GN.js";
import "./chunk-VMGLJXNV.js";
import "./chunk-WVIWW4DP.js";
import "./chunk-GWBU7KI5.js";
import "./chunk-ACDJJVP2.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-YV6YPLCH.js";
import "./chunk-YX3CWYO4.js";
import "./chunk-BUFWSK3Z.js";
import "./chunk-CXAU46CM.js";
import "./chunk-MTMQW4PP.js";
import "./chunk-GOMI4DH3.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
