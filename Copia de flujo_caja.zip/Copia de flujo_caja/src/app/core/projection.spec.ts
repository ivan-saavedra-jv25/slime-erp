import { describe, expect, it } from 'vitest';
import { CashflowState, OneOffItem, Override, RecurringItem } from './models';
import { isActiveIn, projectThrough, projectYear, projectMonth } from './projection';
import { DEFAULT_PROVISIONS, seedState } from './seed';

const NO_PROVISIONS = { ...DEFAULT_PROVISIONS };

function stateWith(patch: Partial<CashflowState>): CashflowState {
  return { ...seedState(2026), ...patch };
}

const arriendo: RecurringItem = {
  id: 'r-arriendo',
  kind: 'expense',
  categoryId: 'cat-arriendo',
  description: 'Arriendo oficina',
  amount: 500_000,
  fromMonth: '2026-01',
  toMonth: null,
  interestAmount: null,
};

const sueldo: RecurringItem = {
  id: 'r-sueldo',
  kind: 'income',
  categoryId: 'cat-ventas',
  description: 'Sueldo',
  amount: 1_200_000,
  fromMonth: '2026-01',
  toMonth: null,
  interestAmount: null,
};

describe('isActiveIn', () => {
  it('incluye los meses límite de la vigencia', () => {
    const item = { ...arriendo, fromMonth: '2026-03', toMonth: '2026-05' };
    expect(isActiveIn(item, '2026-02')).toBe(false);
    expect(isActiveIn(item, '2026-03')).toBe(true);
    expect(isActiveIn(item, '2026-04')).toBe(true);
    expect(isActiveIn(item, '2026-05')).toBe(true);
    expect(isActiveIn(item, '2026-06')).toBe(false);
  });

  it('sin toMonth se extiende indefinidamente', () => {
    expect(isActiveIn(arriendo, '2099-12')).toBe(true);
    expect(isActiveIn(arriendo, '2025-12')).toBe(false);
  });
});

describe('projectMonth', () => {
  it('un mes sin movimientos conserva el saldo', () => {
    const p = projectMonth(stateWith({}), '2026-01', 250_000);
    expect(p.incomes).toEqual([]);
    expect(p.expenses).toEqual([]);
    expect(p.totalIncome).toBe(0);
    expect(p.totalExpense).toBe(0);
    expect(p.net).toBe(0);
    expect(p.closingBalance).toBe(250_000);
  });

  it('separa ingresos y gastos y calcula el neto', () => {
    const p = projectMonth(stateWith({ recurring: [arriendo, sueldo] }), '2026-01', 1_000_000);
    expect(p.incomes.map((l) => l.id)).toEqual(['r-sueldo']);
    expect(p.expenses.map((l) => l.id)).toEqual(['r-arriendo']);
    expect(p.totalIncome).toBe(1_200_000);
    expect(p.totalExpense).toBe(500_000);
    expect(p.net).toBe(700_000);
    expect(p.closingBalance).toBe(1_700_000);
  });

  it('excluye recurrentes fuera de vigencia', () => {
    const item = { ...arriendo, fromMonth: '2026-04', toMonth: '2026-06' };
    expect(projectMonth(stateWith({ recurring: [item] }), '2026-01', 0).expenses).toEqual([]);
    expect(projectMonth(stateWith({ recurring: [item] }), '2026-05', 0).expenses).toHaveLength(1);
  });

  it('incluye puntuales solo en su mes', () => {
    const bono: OneOffItem = {
      id: 'o-bono',
      kind: 'income',
      categoryId: 'cat-otros-ingresos',
      description: 'Bono',
      amount: 300_000,
      month: '2026-02',
      interestAmount: null,
    };
    const state = stateWith({ oneOff: [bono] });
    expect(projectMonth(state, '2026-01', 0).totalIncome).toBe(0);
    const feb = projectMonth(state, '2026-02', 0);
    expect(feb.totalIncome).toBe(300_000);
    expect(feb.incomes[0].source).toBe('oneoff');
  });

  it('un override con monto reemplaza el valor de la plantilla y marca la línea', () => {
    const override: Override = { recurringId: 'r-arriendo', month: '2026-03', amount: 400_000 };
    const state = stateWith({ recurring: [arriendo], overrides: [override] });
    const marzo = projectMonth(state, '2026-03', 0);
    expect(marzo.totalExpense).toBe(400_000);
    expect(marzo.expenses[0].overridden).toBe(true);
    const abril = projectMonth(state, '2026-04', 0);
    expect(abril.totalExpense).toBe(500_000);
    expect(abril.expenses[0].overridden).toBe(false);
  });

  it('un override con amount null omite el recurrente ese mes', () => {
    const override: Override = { recurringId: 'r-arriendo', month: '2026-03', amount: null };
    const state = stateWith({ recurring: [arriendo], overrides: [override] });
    expect(projectMonth(state, '2026-03', 0).expenses).toEqual([]);
    expect(projectMonth(state, '2026-04', 0).expenses).toHaveLength(1);
  });

  it('agrupa por categoría sumando líneas repetidas', () => {
    const state = stateWith({
      recurring: [
        arriendo,
        { ...arriendo, id: 'r-bodega', description: 'Arriendo bodega', amount: 150_000 },
        sueldo,
        { ...sueldo, id: 'r-sueldo-2', description: 'Sueldo 2', amount: 800_000 },
      ],
    });
    const p = projectMonth(state, '2026-01', 0);
    expect(p.expenseByCategory.get('cat-arriendo')).toBe(650_000);
    expect(p.incomeByCategory.get('cat-ventas')).toBe(2_000_000);
  });

  it('acepta saldos iniciales negativos', () => {
    const p = projectMonth(stateWith({ recurring: [arriendo] }), '2026-01', -100_000);
    expect(p.closingBalance).toBe(-600_000);
  });
});

describe('projectYear', () => {
  it('arrastra el saldo final como saldo inicial del mes siguiente', () => {
    const bono: OneOffItem = {
      id: 'o-bono',
      kind: 'income',
      categoryId: 'cat-otros-ingresos',
      description: 'Bono',
      amount: 300_000,
      month: '2026-02',
      interestAmount: null,
    };
    const state = stateWith({
      settings: { baseYear: 2026, openingBalance: 1_000_000, provisions: NO_PROVISIONS },
      recurring: [arriendo, sueldo],
      oneOff: [bono],
    });
    const months = projectYear(state, 2026);
    expect(months).toHaveLength(12);
    expect(months[0].month).toBe('2026-01');
    expect(months[11].month).toBe('2026-12');

    expect(months[0].openingBalance).toBe(1_000_000);
    expect(months[0].closingBalance).toBe(1_700_000);
    expect(months[1].openingBalance).toBe(1_700_000);
    expect(months[1].closingBalance).toBe(2_700_000);
    expect(months[2].openingBalance).toBe(2_700_000);
    expect(months[2].closingBalance).toBe(3_400_000);
  });

  it('el saldo inicial de cada mes es el saldo final del anterior', () => {
    const state = stateWith({
      settings: { baseYear: 2026, openingBalance: 50_000, provisions: NO_PROVISIONS },
      recurring: [arriendo, sueldo],
    });
    const months = projectYear(state, 2026);
    for (let i = 1; i < months.length; i++) {
      expect(months[i].openingBalance).toBe(months[i - 1].closingBalance);
    }
  });

  it('siempre devuelve enero a diciembre del año pedido', () => {
    const state = stateWith({
      settings: { baseYear: 2026, openingBalance: 0, provisions: NO_PROVISIONS },
    });
    const months = projectYear(state, 2028).map((m) => m.month);
    expect(months).toHaveLength(12);
    expect(months[0]).toBe('2028-01');
    expect(months[11]).toBe('2028-12');
  });

  it('encadena los años: enero parte con el cierre de diciembre anterior', () => {
    const state = stateWith({
      settings: { baseYear: 2026, openingBalance: 1_000_000, provisions: NO_PROVISIONS },
      recurring: [{ ...sueldo, amount: 100_000 }],
    });
    const dic2026 = projectYear(state, 2026)[11];
    const ene2027 = projectYear(state, 2027)[0];
    expect(dic2026.closingBalance).toBe(1_000_000 + 12 * 100_000);
    expect(ene2027.openingBalance).toBe(dic2026.closingBalance);
    expect(projectYear(state, 2027)[11].closingBalance).toBe(1_000_000 + 24 * 100_000);
  });

  it('un año anterior al base se trata como el año base', () => {
    const state = stateWith({
      settings: { baseYear: 2026, openingBalance: 500, provisions: NO_PROVISIONS },
    });
    expect(projectYear(state, 2024)[0].month).toBe('2026-01');
    expect(projectYear(state, 2024)[0].openingBalance).toBe(500);
  });

  it('projectThrough cubre todos los meses desde el año base', () => {
    const state = stateWith({
      settings: { baseYear: 2026, openingBalance: 0, provisions: NO_PROVISIONS },
    });
    const months = projectThrough(state, 2027);
    expect(months).toHaveLength(24);
    expect(months[0].month).toBe('2026-01');
    expect(months[23].month).toBe('2027-12');
  });

  it('propaga saldos negativos sin recortarlos', () => {
    const state = stateWith({
      settings: { baseYear: 2026, openingBalance: 100_000, provisions: NO_PROVISIONS },
      recurring: [arriendo],
    });
    expect(
      projectYear(state, 2026)
        .slice(0, 3)
        .map((m) => m.closingBalance),
    ).toEqual([-400_000, -900_000, -1_400_000]);
  });
});
