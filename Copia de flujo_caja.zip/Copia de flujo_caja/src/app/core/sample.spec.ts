import { describe, expect, it } from 'vitest';
import { projectYear } from './projection';
import { sampleState } from './sample';
import { parseState } from './storage.service';

describe('sampleState', () => {
  const state = sampleState(2026);

  it('es un estado válido según el validador de storage', () => {
    expect(parseState(JSON.parse(JSON.stringify(state)))).not.toBeNull();
  });

  it('trae ventas mensuales como ingreso y sueldos, arriendo y servicios como gastos', () => {
    const descriptions = state.recurring.map((r) => r.description);
    expect(descriptions).toContain('Ventas mensuales');
    expect(descriptions).toContain('Sueldos y cotizaciones');
    expect(descriptions).toContain('Arriendo oficina');
    expect(descriptions).toContain('Cuota crédito capital de trabajo');
    expect(state.recurring.filter((r) => r.kind === 'income')).toHaveLength(1);
    expect(state.recurring.filter((r) => r.kind === 'expense')).toHaveLength(4);
  });

  it('todos los ítems apuntan a categorías existentes', () => {
    const ids = new Set(state.categories.map((c) => c.id));
    for (const item of [...state.recurring, ...state.oneOff]) {
      expect(ids.has(item.categoryId)).toBe(true);
    }
  });

  it('los overrides apuntan a recurrentes existentes', () => {
    const ids = new Set(state.recurring.map((r) => r.id));
    for (const override of state.overrides) {
      expect(ids.has(override.recurringId)).toBe(true);
    }
  });

  it('separa el servicio de deuda del gasto de operación', () => {
    const [enero] = projectYear(state, 2026);
    expect(enero.financingExpense).toBe(620_000);
    expect(enero.debtInterest).toBe(180_000);
    expect(enero.debtPrincipal).toBe(440_000);
    // La cuota no ensucia el resultado del giro.
    expect(enero.operationalExpense).toBe(2_600_000 + 450_000 + 220_000 + 380_000);
    expect(enero.operationalNet).toBe(8_000_000 - enero.operationalExpense);
  });

  it('clasifica la venta de activo como ingreso no operacional', () => {
    const julio = projectYear(state, 2026)[6];
    expect(julio.operationalIncome).toBe(8_000_000);
    expect(julio.nonOperationalIncome).toBe(1_200_000);
  });

  it('provisiona impuestos y colchón sobre el saldo', () => {
    const months = projectYear(state, 2026);
    const enero = months[0];
    expect(enero.taxProvision).toBeCloseTo(enero.operationalNet * 0.27, 5);
    expect(enero.contingencyTarget).toBe(enero.fixedExpense * 2);
    // El impuesto se descuenta del disponible; el colchón sólo se compara.
    expect(enero.availableBalance).toBeCloseTo(
      enero.closingBalance - enero.accumulatedTaxProvision,
      5,
    );
    expect(enero.contingencyGap).toBeCloseTo(enero.contingencyTarget - enero.availableBalance, 5);
    // La provisión de impuestos se acumula mes a mes.
    expect(months[11].accumulatedTaxProvision).toBeGreaterThan(enero.accumulatedTaxProvision);
  });

  it('incluye una crisis: caída de ventas y dos sobregastos', () => {
    const months = projectYear(state, 2026);
    expect(months).toHaveLength(12);
    expect(months[0].openingBalance).toBe(3_000_000);
    // Las ventas caen de febrero a mayo por override.
    expect(months[3].incomes.find((l) => l.description === 'Ventas mensuales')!.amount).toBe(
      2_900_000,
    );
    // Y encima caen dos gastos grandes que no se repiten.
    expect(months[3].expenses.some((l) => l.description === 'Reparación de maquinaria')).toBe(true);
    expect(months[4].expenses.some((l) => l.description.startsWith('Indemnizaciones'))).toBe(true);
    expect(months.filter((m) => m.net < 0)).toHaveLength(3);
    expect(months.filter((m) => m.closingBalance < 0)).toHaveLength(1);
    // El año se recupera: diciembre cierra por sobre el saldo inicial.
    expect(months[11].closingBalance).toBeGreaterThan(months[0].openingBalance);
  });

  it('los ajustes de ventas duran sólo los meses marcados', () => {
    const months = projectYear(state, 2026);
    const ventasDe = (index: number) =>
      months[index].incomes.find((l) => l.description === 'Ventas mensuales')!;
    expect(ventasDe(0).amount).toBe(8_000_000);
    expect(ventasDe(1).amount).toBe(5_800_000);
    expect(ventasDe(1).overridden).toBe(true);
    // Junio ya no tiene ajuste: la serie vuelve sola a su monto.
    expect(ventasDe(5).amount).toBe(8_000_000);
    expect(ventasDe(5).overridden).toBe(false);
  });

  it('reparte los movimientos puntuales en sus meses', () => {
    const months = projectYear(state, 2026);
    expect(months[0].expenses.some((l) => l.description === 'Patente municipal')).toBe(true);
    expect(months[6].incomes.some((l) => l.description.startsWith('Venta de equipo'))).toBe(true);
    expect(months[8].expenses.some((l) => l.description.includes('fiestas patrias'))).toBe(true);
    expect(months[11].expenses.some((l) => l.description.includes('navidad'))).toBe(true);
  });

  it('usa el año pedido', () => {
    const other = sampleState(2030);
    expect(other.settings.baseYear).toBe(2030);
    expect(other.recurring[0].fromMonth).toBe('2030-01');
    expect(other.oneOff[0].month).toBe('2030-01');
  });
});
