import { beforeEach, describe, expect, it } from 'vitest';
import { parseState, STORAGE_KEY, StorageService } from './storage.service';
import { MemoryStorage } from './memory-storage';
import { seedState } from './seed';
import { CashflowState } from './models';

function fullState(): CashflowState {
  const state = seedState(2026);
  state.settings.openingBalance = 1_000_000;
  state.recurring.push({
    id: 'r-1',
    kind: 'expense',
    categoryId: 'cat-arriendo',
    description: 'Arriendo',
    amount: 500_000,
    fromMonth: '2026-01',
    toMonth: null,
    interestAmount: null,
  });
  state.oneOff.push({
    id: 'o-1',
    kind: 'income',
    categoryId: 'cat-ventas',
    description: 'Bono',
    amount: 300_000,
    month: '2026-02',
    interestAmount: null,
  });
  state.overrides.push({ recurringId: 'r-1', month: '2026-03', amount: 400_000 });
  return state;
}

describe('parseState', () => {
  it('acepta un estado completo', () => {
    expect(parseState(JSON.parse(JSON.stringify(fullState())))).toEqual(fullState());
  });

  it('acepta overrides con amount null', () => {
    const state = fullState();
    state.overrides = [{ recurringId: 'r-1', month: '2026-03', amount: null }];
    expect(parseState(JSON.parse(JSON.stringify(state)))?.overrides[0].amount).toBeNull();
  });

  it('rechaza versiones distintas', () => {
    expect(parseState({ ...fullState(), version: 99 })).toBeNull();
  });

  it('rechaza versiones anteriores sin migrar', () => {
    expect(parseState({ ...fullState(), version: 1 })).toBeNull();
    expect(parseState({ ...fullState(), version: 2 })).toBeNull();
  });

  it('rechaza categorías sin clasificar', () => {
    const state = JSON.parse(JSON.stringify(fullState()));
    delete state.categories[0].nature;
    expect(parseState(state)).toBeNull();
  });

  it('rechaza un interés mayor que la cuota', () => {
    const state = JSON.parse(JSON.stringify(fullState()));
    state.recurring[0].interestAmount = state.recurring[0].amount + 1;
    expect(parseState(state)).toBeNull();
  });

  it('rechaza provisiones fuera de rango', () => {
    const state = JSON.parse(JSON.stringify(fullState()));
    state.settings.provisions.taxRatePercent = 130;
    expect(parseState(state)).toBeNull();
  });

  it('rechaza años fuera de rango', () => {
    const state = JSON.parse(JSON.stringify(fullState()));
    state.settings.baseYear = 1800;
    expect(parseState(state)).toBeNull();
    state.settings.baseYear = '2026';
    expect(parseState(state)).toBeNull();
  });

  it('rechaza montos no numéricos', () => {
    const state = JSON.parse(JSON.stringify(fullState()));
    state.recurring[0].amount = '500000';
    expect(parseState(state)).toBeNull();
  });

  it('rechaza colecciones que no son arreglos', () => {
    const state = JSON.parse(JSON.stringify(fullState()));
    state.categories = {};
    expect(parseState(state)).toBeNull();
  });

  it('rechaza saldos iniciales no numéricos', () => {
    const state = JSON.parse(JSON.stringify(fullState()));
    state.settings.openingBalance = '1000';
    expect(parseState(state)).toBeNull();
  });

  it('rechaza valores que no son objetos', () => {
    expect(parseState(null)).toBeNull();
    expect(parseState('texto')).toBeNull();
    expect(parseState([])).toBeNull();
  });
});

describe('StorageService', () => {
  let service: StorageService;
  let backend: MemoryStorage;

  beforeEach(() => {
    backend = new MemoryStorage();
    service = new StorageService(backend);
  });

  it('sin datos guardados devuelve el estado semilla', () => {
    const result = service.load();
    expect(result.corrupted).toBe(false);
    expect(result.state.recurring).toEqual([]);
    expect(result.state.categories.length).toBeGreaterThan(0);
  });

  it('guarda y recupera el mismo estado', () => {
    const state = fullState();
    service.save(state);
    const result = service.load();
    expect(result.corrupted).toBe(false);
    expect(result.state).toEqual(state);
  });

  it('con JSON corrupto vuelve al estado semilla y lo reporta', () => {
    backend.setItem(STORAGE_KEY, '{no es json');
    const result = service.load();
    expect(result.corrupted).toBe(true);
    expect(result.state.recurring).toEqual([]);
  });

  it('con JSON válido pero forma inválida también reporta corrupción', () => {
    backend.setItem(STORAGE_KEY, JSON.stringify({ version: 1, settings: {} }));
    expect(service.load().corrupted).toBe(true);
  });

  it('clear borra los datos guardados', () => {
    service.save(fullState());
    service.clear();
    expect(backend.getItem(STORAGE_KEY)).toBeNull();
  });

  it('migra un estado v1 hasta la versión actual', () => {
    const current = fullState();
    const legacy = {
      version: 1,
      settings: { startMonth: '2026-09', openingBalance: 1_000_000, horizonMonths: 6 },
      categories: current.categories.map(({ id, name, kind }) => ({ id, name, kind })),
      recurring: current.recurring.map(({ interestAmount, ...rest }) => rest),
      oneOff: current.oneOff.map(({ interestAmount, ...rest }) => rest),
      overrides: current.overrides,
    };
    backend.setItem(STORAGE_KEY, JSON.stringify(legacy));

    const result = service.load();
    expect(result.corrupted).toBe(false);
    expect(result.state.version).toBe(3);
    expect(result.state.settings.baseYear).toBe(2026);
    expect(result.state.settings.openingBalance).toBe(1_000_000);
    expect(result.state.settings.provisions).toEqual({ taxRatePercent: 0, contingencyMonths: 0 });
    // Lo guardado se asume operacional; los gastos, fijos.
    expect(result.state.categories.every((c) => c.nature === 'operational')).toBe(true);
    const gasto = result.state.categories.find((c) => c.kind === 'expense')!;
    expect(gasto.variability).toBe('fixed');
    // Los movimientos se conservan tal cual.
    expect(result.state.recurring).toHaveLength(1);
    expect(result.state.recurring[0].interestAmount).toBeNull();
    expect(result.state.oneOff).toHaveLength(1);
    expect(result.state.overrides).toHaveLength(1);
  });

  it('migra un estado v2 agregando clasificación y provisiones', () => {
    const current = fullState();
    const legacy = {
      version: 2,
      settings: { baseYear: 2026, openingBalance: 1_000_000 },
      categories: current.categories.map(({ id, name, kind }) => ({ id, name, kind })),
      recurring: current.recurring.map(({ interestAmount, ...rest }) => rest),
      oneOff: current.oneOff.map(({ interestAmount, ...rest }) => rest),
      overrides: current.overrides,
    };
    backend.setItem(STORAGE_KEY, JSON.stringify(legacy));

    const result = service.load();
    expect(result.corrupted).toBe(false);
    expect(result.state.version).toBe(3);
    expect(result.state.settings.provisions.taxRatePercent).toBe(0);
  });

  it('deja intacto un estado que ya está en la versión actual', () => {
    service.save(fullState());
    expect(service.load().state).toEqual(fullState());
  });

  it('sin backend disponible funciona en memoria sin romperse', () => {
    const offline = new StorageService(null);
    expect(offline.load().corrupted).toBe(false);
    expect(() => offline.save(fullState())).not.toThrow();
    expect(() => offline.clear()).not.toThrow();
  });

  it('deserialize rechaza respaldos inválidos', () => {
    expect(service.deserialize('no json')).toBeNull();
    expect(service.deserialize('{"version":2}')).toBeNull();
    expect(service.deserialize(service.serialize(fullState()))).toEqual(fullState());
  });
});
