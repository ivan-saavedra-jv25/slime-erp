import { describe, expect, it } from 'vitest';
import { monthStatus, yearAlerts } from './health';
import { MonthProjection } from './projection';

function month(patch: Partial<MonthProjection>): MonthProjection {
  return {
    month: '2026-01',
    openingBalance: 0,
    incomes: [],
    expenses: [],
    incomeByCategory: new Map(),
    expenseByCategory: new Map(),
    totalIncome: 0,
    totalExpense: 0,
    net: 0,
    closingBalance: 0,
    operationalIncome: 0,
    nonOperationalIncome: 0,
    financingIncome: 0,
    operationalExpense: 0,
    nonOperationalExpense: 0,
    financingExpense: 0,
    debtPrincipal: 0,
    debtInterest: 0,
    fixedExpense: 0,
    fixedRecurringExpense: 0,
    variableExpense: 0,
    operationalNet: 0,
    taxProvision: 0,
    accumulatedTaxProvision: 0,
    contingencyTarget: 0,
    availableBalance: 0,
    contingencyGap: 0,
    ...patch,
  };
}

describe('monthStatus', () => {
  it('un mes sano no dispara nada', () => {
    const status = monthStatus(month({ net: 100, closingBalance: 100, availableBalance: 100 }));
    expect(status.health).toBe('ok');
    expect(status.reasons).toEqual([]);
  });

  it('saldo negativo es crítico', () => {
    const status = monthStatus(month({ closingBalance: -1, availableBalance: -1, net: -1 }));
    expect(status.health).toBe('critical');
    expect(status.reasons[0]).toContain('negativo');
  });

  it('un saldo positivo que no cubre los impuestos también es crítico', () => {
    const status = monthStatus(
      month({ closingBalance: 100, availableBalance: -50, net: 100, accumulatedTaxProvision: 150 }),
    );
    expect(status.health).toBe('critical');
    expect(status.reasons[0]).toContain('impuestos');
  });

  it('gastar más de lo que entra es advertencia si el saldo aguanta', () => {
    const status = monthStatus(
      month({ net: -500, closingBalance: 1_000, availableBalance: 1_000 }),
    );
    expect(status.health).toBe('warning');
    expect(status.reasons).toContain('Se gasta más de lo que entra');
  });

  it('quedar bajo el colchón es advertencia', () => {
    const status = monthStatus(
      month({ net: 100, closingBalance: 500, availableBalance: 500, contingencyTarget: 900 }),
    );
    expect(status.health).toBe('warning');
    expect(status.reasons[0]).toContain('colchón');
  });

  it('sin colchón configurado no se advierte por colchón', () => {
    const status = monthStatus(
      month({ net: 100, closingBalance: 500, availableBalance: 500, contingencyTarget: 0 }),
    );
    expect(status.health).toBe('ok');
  });

  it('un mes crítico acumula sus razones', () => {
    const status = monthStatus(
      month({ net: -100, closingBalance: -100, availableBalance: -100, contingencyTarget: 900 }),
    );
    expect(status.health).toBe('critical');
    expect(status.reasons.length).toBeGreaterThan(1);
  });
});

describe('yearAlerts', () => {
  it('cuenta críticos y advertencias por separado', () => {
    const alerts = yearAlerts([
      month({ net: 10, closingBalance: 10, availableBalance: 10 }),
      month({ net: -10, closingBalance: 10, availableBalance: 10 }),
      month({ net: -10, closingBalance: -10, availableBalance: -10 }),
    ]);
    expect(alerts).toEqual({ critical: 1, warning: 1, total: 2 });
  });
});
