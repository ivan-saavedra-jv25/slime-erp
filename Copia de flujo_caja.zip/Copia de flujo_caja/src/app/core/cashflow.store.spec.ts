import { TestBed } from '@angular/core/testing';
import { beforeEach, describe, expect, it } from 'vitest';
import { CashflowStore } from './cashflow.store';
import { MemoryStorage } from './memory-storage';
import { STORAGE_BACKEND } from './storage.service';
import { seedState } from './seed';

describe('CashflowStore', () => {
  let backend: MemoryStorage;
  let store: CashflowStore;

  beforeEach(() => {
    backend = new MemoryStorage();
    TestBed.configureTestingModule({
      providers: [{ provide: STORAGE_BACKEND, useValue: backend }],
    });
    store = TestBed.inject(CashflowStore);
    store.setBaseYear(2026);
    store.updateSettings({ openingBalance: 1_000_000 });
    store.setYear(2026);
  });

  it('parte del estado semilla con categorías por defecto', () => {
    expect(store.categories().length).toBeGreaterThan(0);
    expect(store.incomeCategories().every((c) => c.kind === 'income')).toBe(true);
    expect(store.expenseCategories().every((c) => c.kind === 'expense')).toBe(true);
  });

  it('recalcula la proyección al agregar ítems', () => {
    store.addRecurring({
      kind: 'expense',
      categoryId: 'cat-arriendo',
      description: 'Arriendo',
      amount: 500_000,
      fromMonth: '2026-01',
      toMonth: null,
      interestAmount: null,
    });
    store.addRecurring({
      kind: 'income',
      categoryId: 'cat-ventas',
      description: 'Sueldo',
      amount: 1_200_000,
      fromMonth: '2026-01',
      toMonth: null,
      interestAmount: null,
    });
    store.addOneOff({
      kind: 'income',
      categoryId: 'cat-otros-ingresos',
      description: 'Bono',
      amount: 300_000,
      month: '2026-02',
      interestAmount: null,
    });

    const months = store.projection();
    expect(months[0].closingBalance).toBe(1_700_000);
    expect(months[1].openingBalance).toBe(1_700_000);
    expect(months[1].closingBalance).toBe(2_700_000);
  });

  it('persiste cada cambio en el almacenamiento', () => {
    TestBed.tick();
    store.addOneOff({
      kind: 'income',
      categoryId: 'cat-ventas',
      description: 'Venta',
      amount: 100_000,
      month: '2026-01',
      interestAmount: null,
    });
    TestBed.tick();
    const saved = JSON.parse(backend.getItem('flujo-caja:v1')!);
    expect(saved.oneOff).toHaveLength(1);
    expect(saved.oneOff[0].description).toBe('Venta');
  });

  it('borrar un recurrente elimina sus overrides', () => {
    const item = store.addRecurring({
      kind: 'expense',
      categoryId: 'cat-arriendo',
      description: 'Arriendo',
      amount: 500_000,
      fromMonth: '2026-01',
      toMonth: null,
      interestAmount: null,
    });
    store.setOverride(item.id, '2026-03', 400_000);
    expect(store.state().overrides).toHaveLength(1);
    store.removeRecurring(item.id);
    expect(store.state().overrides).toEqual([]);
  });

  it('setOverride reemplaza el override del mismo mes sin duplicar', () => {
    const item = store.addRecurring({
      kind: 'expense',
      categoryId: 'cat-arriendo',
      description: 'Arriendo',
      amount: 500_000,
      fromMonth: '2026-01',
      toMonth: null,
      interestAmount: null,
    });
    store.setOverride(item.id, '2026-03', 400_000);
    store.setOverride(item.id, '2026-03', 300_000);
    expect(store.state().overrides).toHaveLength(1);
    expect(store.projection()[2].totalExpense).toBe(300_000);
    store.clearOverride(item.id, '2026-03');
    expect(store.projection()[2].totalExpense).toBe(500_000);
  });

  it('no borra categorías en uso', () => {
    store.addRecurring({
      kind: 'expense',
      categoryId: 'cat-arriendo',
      description: 'Arriendo',
      amount: 1,
      fromMonth: '2026-01',
      toMonth: null,
      interestAmount: null,
    });
    expect(store.removeCategory('cat-arriendo')).toBe(false);
    expect(store.removeCategory('cat-servicios')).toBe(true);
  });

  it('reencuadra el mes seleccionado al cambiar de año', () => {
    store.selectMonth('2026-12');
    store.setYear(2027);
    expect(store.selectedMonth()).toBe('2027-01');
  });

  it('setYear muestra enero a diciembre del año elegido', () => {
    store.setYear(2028);
    expect(store.year()).toBe(2028);
    const months = store.months();
    expect(months).toHaveLength(12);
    expect(months[0]).toBe('2028-01');
    expect(months[11]).toBe('2028-12');
    // El año base no se mueve: el saldo inicial sigue siendo el de 2026.
    expect(store.baseYear()).toBe(2026);
  });

  it('no permite ver años anteriores al año base', () => {
    expect(store.canGoToPreviousYear()).toBe(false);
    store.setYear(2020);
    expect(store.year()).toBe(2026);
    store.setYear(2027);
    expect(store.canGoToPreviousYear()).toBe(true);
  });

  it('encadena el saldo entre años', () => {
    store.addRecurring({
      kind: 'income',
      categoryId: 'cat-ventas',
      description: 'Sueldo',
      amount: 1_000_000,
      fromMonth: '2026-01',
      toMonth: null,
      interestAmount: null,
    });
    const cierre2026 = store.projection()[11].closingBalance;
    expect(cierre2026).toBe(1_000_000 + 12 * 1_000_000);

    store.setYear(2027);
    expect(store.state().recurring).toHaveLength(1);
    expect(store.yearOpeningBalance()).toBe(cierre2026);
    expect(store.isCarriedOver()).toBe(true);
    expect(store.projection()[11].closingBalance).toBe(1_000_000 + 24 * 1_000_000);
  });

  it('mover el año base arrastra el año visible si quedó antes', () => {
    store.setBaseYear(2030);
    expect(store.baseYear()).toBe(2030);
    expect(store.year()).toBe(2030);
  });

  it('importa respaldos válidos y rechaza los inválidos', () => {
    const backup = seedState(2030);
    expect(store.importBackup(JSON.stringify(backup))).toBe(true);
    expect(store.baseYear()).toBe(2030);
    expect(store.year()).toBe(2030);
    expect(store.selectedMonth()).toBe('2030-01');
    expect(store.importBackup('{roto')).toBe(false);
    expect(store.baseYear()).toBe(2030);
  });
});
