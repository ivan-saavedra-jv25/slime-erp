import { describe, expect, it } from 'vitest';
import { buildAudit } from './audit';
import { monthStatus, yearAlerts } from './health';
import { projectYear } from './projection';
import { sampleState } from './sample';

describe('el flujo de ejemplo, de punta a punta', () => {
  const state = sampleState(2026);
  const months = projectYear(state, 2026);

  it('saldos y disponible', () => {
    expect(months.map((m) => m.closingBalance)).toEqual([
      6_730_000, 8_640_000, 8_150_000, 2_660_000, -3_630_000, 480_000, 5_790_000, 9_900_000,
      13_110_000, 17_220_000, 21_330_000, 24_540_000,
    ]);
    expect(months[11].accumulatedTaxProvision).toBeCloseTo(10_346_400, 2);
    expect(months[11].availableBalance).toBeCloseTo(14_193_600, 2);
    expect(months[11].contingencyTarget).toBe(7_340_000);
  });

  it('el semáforo marca la crisis de marzo a junio', () => {
    expect(months.map((m) => monthStatus(m).health)).toEqual([
      'warning',
      'warning',
      'warning',
      'warning',
      'critical',
      'critical',
      'warning',
      'warning',
      'warning',
      'ok',
      'ok',
      'ok',
    ]);
    expect(yearAlerts(months)).toEqual({ critical: 2, warning: 7, total: 9 });
    // Mayo cierra en negativo; junio cierra positivo pero no cubre los impuestos.
    expect(monthStatus(months[4]).reasons[0]).toContain('negativo');
    expect(monthStatus(months[5]).reasons[0]).toContain('impuestos');
  });

  it('estados de la auditoría', () => {
    const report = buildAudit(state, months, 2026);
    expect(report.checks.map((c) => `${c.id}:${c.status}`)).toEqual([
      'liquidez:fail',
      'punto-critico:info',
      'ingresos-clasificados:pass',
      'desfase-cobro:info',
      'estructura-gastos:warn',
      'provisiones:pass',
      'capacidad-pago:fail',
      'excedentes:fail',
    ]);
    // Sin margen: mayo cierra en rojo, no hay cuota nueva que el flujo aguante.
    const capacidad = report.checks.find((c) => c.id === 'capacidad-pago')!;
    expect(capacidad.figures[0].amount).toBe(0);
  });
});
