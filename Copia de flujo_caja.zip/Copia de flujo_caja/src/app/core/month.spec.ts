import { describe, expect, it } from 'vitest';
import {
  addMonths,
  currentMonthKey,
  dateToMonthKey,
  formatMonthLabel,
  isValidMonthKey,
  monthDiff,
  monthKeyToDate,
  monthKeysFrom,
  parseMonth,
  toMonthKey,
} from './month';

describe('month', () => {
  it('valida el formato YYYY-MM', () => {
    expect(isValidMonthKey('2026-01')).toBe(true);
    expect(isValidMonthKey('2026-12')).toBe(true);
    expect(isValidMonthKey('2026-13')).toBe(false);
    expect(isValidMonthKey('2026-00')).toBe(false);
    expect(isValidMonthKey('2026-1')).toBe(false);
    expect(isValidMonthKey(202601)).toBe(false);
  });

  it('parsea y rechaza claves inválidas', () => {
    expect(parseMonth('2026-03')).toEqual({ year: 2026, month: 3 });
    expect(() => parseMonth('2026-3')).toThrow();
  });

  it('rellena con ceros al construir', () => {
    expect(toMonthKey(2026, 3)).toBe('2026-03');
    expect(toMonthKey(2026, 12)).toBe('2026-12');
  });

  it('suma meses cruzando el año', () => {
    expect(addMonths('2026-01', 1)).toBe('2026-02');
    expect(addMonths('2026-12', 1)).toBe('2027-01');
    expect(addMonths('2026-11', 3)).toBe('2027-02');
    expect(addMonths('2026-01', -1)).toBe('2025-12');
    expect(addMonths('2026-01', -13)).toBe('2024-12');
    expect(addMonths('2026-05', 0)).toBe('2026-05');
  });

  it('calcula diferencias en meses', () => {
    expect(monthDiff('2026-03', '2026-01')).toBe(2);
    expect(monthDiff('2026-01', '2026-03')).toBe(-2);
    expect(monthDiff('2027-01', '2026-01')).toBe(12);
  });

  it('genera series de meses', () => {
    expect(monthKeysFrom('2026-11', 4)).toEqual(['2026-11', '2026-12', '2027-01', '2027-02']);
    expect(monthKeysFrom('2026-01', 0)).toEqual([]);
    expect(monthKeysFrom('2026-01', -3)).toEqual([]);
  });

  it('ordena lexicográficamente igual que cronológicamente', () => {
    const keys = monthKeysFrom('2026-09', 6);
    expect([...keys].sort()).toEqual(keys);
  });

  it('formatea etiquetas legibles', () => {
    expect(formatMonthLabel('2026-01')).toBe('Ene 2026');
    expect(formatMonthLabel('2026-12')).toBe('Dic 2026');
  });

  it('convierte a Date y de vuelta sin perder el mes', () => {
    const date = monthKeyToDate('2026-03');
    expect(date.getFullYear()).toBe(2026);
    expect(date.getMonth()).toBe(2);
    expect(date.getDate()).toBe(1);
    expect(dateToMonthKey(date)).toBe('2026-03');
  });

  it('deriva el mes actual de una fecha dada', () => {
    expect(currentMonthKey(new Date(2026, 8, 1))).toBe('2026-09');
  });
});
