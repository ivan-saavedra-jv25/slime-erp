import { describe, expect, it } from 'vitest';
import { buildAudit, AuditCheck } from './audit';
import { CashflowState, RecurringItem } from './models';
import { projectYear } from './projection';
import { sampleState } from './sample';
import { seedState } from './seed';

function auditOf(state: CashflowState, year = 2026) {
  return buildAudit(state, projectYear(state, year), year);
}

function check(state: CashflowState, id: string): AuditCheck {
  return auditOf(state).checks.find((c) => c.id === id)!;
}

function recurring(patch: Partial<RecurringItem>): RecurringItem {
  return {
    id: `r-${patch.description ?? 'x'}`,
    kind: 'expense',
    categoryId: 'cat-arriendo',
    description: 'Gasto',
    amount: 100_000,
    fromMonth: '2026-01',
    toMonth: null,
    interestAmount: null,
    ...patch,
  };
}

describe('buildAudit', () => {
  it('cubre las ocho preguntas de la checklist', () => {
    const report = auditOf(sampleState(2026));
    expect(report.checks.map((c) => c.id)).toEqual([
      'liquidez',
      'punto-critico',
      'ingresos-clasificados',
      'desfase-cobro',
      'estructura-gastos',
      'provisiones',
      'capacidad-pago',
      'excedentes',
    ]);
    expect(report.passed + report.warned + report.failed).toBeLessThanOrEqual(8);
  });

  it('marca liquidez en falla cuando algún mes cierra en rojo', () => {
    const state = seedState(2026);
    state.settings.openingBalance = 0;
    state.recurring = [recurring({ amount: 500_000 })];
    const liquidez = check(state, 'liquidez');
    expect(liquidez.status).toBe('fail');
    expect(liquidez.figures[0].amount).toBe(-6_000_000);
  });

  it('el punto crítico distingue el peor saldo del peor resultado', () => {
    const state = seedState(2026);
    state.settings.openingBalance = 1_000_000;
    state.recurring = [
      recurring({
        kind: 'income',
        categoryId: 'cat-ventas',
        description: 'Ventas',
        amount: 900_000,
      }),
    ];
    state.oneOff = [
      {
        id: 'o-1',
        kind: 'expense',
        categoryId: 'cat-otros-gastos',
        description: 'Pago grande',
        amount: 800_000,
        month: '2026-02',
        interestAmount: null,
      },
    ];
    const critico = check(state, 'punto-critico');
    // El saldo más bajo es enero, pero el mes que menos caja genera es febrero.
    expect(critico.figures[0].month).toBe('2026-01');
    expect(critico.figures[1].month).toBe('2026-02');
    expect(critico.status).toBe('info');
  });

  it('advierte cuando buena parte de los ingresos no viene del giro', () => {
    const state = seedState(2026);
    state.recurring = [
      recurring({
        kind: 'income',
        categoryId: 'cat-ventas',
        description: 'Ventas',
        amount: 100_000,
      }),
      recurring({
        kind: 'income',
        categoryId: 'cat-financiamiento',
        description: 'Préstamo',
        amount: 100_000,
      }),
    ];
    const ingresos = check(state, 'ingresos-clasificados');
    expect(ingresos.status).toBe('warn');
    expect(ingresos.figures.find((f) => f.label === 'Financiamiento')!.amount).toBe(1_200_000);
  });

  it('advierte estructura rígida cuando dominan los gastos fijos', () => {
    const state = seedState(2026);
    state.recurring = [
      recurring({ categoryId: 'cat-arriendo', description: 'Arriendo', amount: 900_000 }),
      recurring({ categoryId: 'cat-servicios', description: 'Servicios', amount: 100_000 }),
    ];
    const gastos = check(state, 'estructura-gastos');
    expect(gastos.status).toBe('warn');
    expect(gastos.figures[0].amount).toBe(10_800_000);
    expect(gastos.figures[1].amount).toBe(1_200_000);
  });

  it('separa capital e interés del servicio de deuda', () => {
    const state = seedState(2026);
    state.recurring = [
      recurring({
        categoryId: 'cat-deuda',
        description: 'Cuota',
        amount: 500_000,
        interestAmount: 120_000,
      }),
    ];
    const gastos = check(state, 'estructura-gastos');
    expect(gastos.figures.find((f) => f.label === 'Servicio de deuda')!.amount).toBe(6_000_000);
    expect(gastos.figures.find((f) => f.label === 'De eso, interés')!.amount).toBe(1_440_000);
  });

  it('reprueba provisiones cuando no hay ninguna configurada', () => {
    expect(check(seedState(2026), 'provisiones').status).toBe('fail');
  });

  it('aprueba provisiones cuando hay impuestos y colchón', () => {
    expect(check(sampleState(2026), 'provisiones').status).toBe('pass');
  });

  it('reprueba capacidad de pago cuando no hay margen', () => {
    const state = seedState(2026);
    state.settings.openingBalance = 0;
    state.recurring = [recurring({ amount: 100_000 })];
    expect(check(state, 'capacidad-pago').status).toBe('fail');
  });

  it('la cuota máxima nunca deja el disponible bajo cero', () => {
    // Flujo sano: el ejemplo trae una crisis y ahí la capacidad es cero.
    const state = seedState(2026);
    state.settings.openingBalance = 2_000_000;
    state.settings.provisions = { taxRatePercent: 27, contingencyMonths: 1 };
    state.recurring = [
      recurring({
        kind: 'income',
        categoryId: 'cat-ventas',
        description: 'Ventas',
        amount: 6_000_000,
      }),
      recurring({ categoryId: 'cat-sueldos', description: 'Sueldos', amount: 3_000_000 }),
    ];

    const capacidad = check(state, 'capacidad-pago');
    const cuota = capacidad.figures[0].amount;
    expect(cuota).toBeGreaterThan(0);

    const months = projectYear(state, 2026);
    months.forEach((m, i) => {
      expect(m.availableBalance - cuota * (i + 1)).toBeGreaterThanOrEqual(-0.01);
    });
  });

  it('el ejemplo con crisis no deja margen para deuda nueva', () => {
    const capacidad = check(sampleState(2026), 'capacidad-pago');
    expect(capacidad.status).toBe('fail');
    expect(capacidad.figures[0].amount).toBe(0);
  });

  it('reprueba excedentes cuando hay meses en déficit', () => {
    const state = seedState(2026);
    state.settings.openingBalance = 0;
    state.recurring = [recurring({ amount: 500_000 })];
    expect(check(state, 'excedentes').status).toBe('fail');
  });

  it('advierte excedente ocioso cuando sobra caja sin destino', () => {
    const state = seedState(2026);
    state.settings.openingBalance = 50_000_000;
    state.recurring = [recurring({ categoryId: 'cat-arriendo', amount: 100_000 })];
    expect(check(state, 'excedentes').status).toBe('warn');
  });

  it('los hallazgos nombran los meses en texto, nunca la clave cruda', () => {
    for (const check of auditOf(sampleState(2026)).checks) {
      expect(check.finding).not.toMatch(/\d{4}-\d{2}/);
      expect(check.advice).not.toMatch(/\d{4}-\d{2}/);
    }
  });

  it('el desfase de cobro siempre es informativo: la app no puede detectarlo', () => {
    expect(check(sampleState(2026), 'desfase-cobro').status).toBe('info');
  });
});
