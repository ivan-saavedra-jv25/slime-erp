import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'resumen' },
  {
    path: 'resumen',
    title: 'Resumen anual',
    loadComponent: () => import('./dashboard/dashboard').then((m) => m.Dashboard),
  },
  {
    path: 'mes',
    title: 'Detalle mensual',
    loadComponent: () => import('./month/month-detail').then((m) => m.MonthDetail),
  },
  {
    path: 'auditoria',
    title: 'Auditoría',
    loadComponent: () => import('./audit/audit-page').then((m) => m.AuditPage),
  },
  {
    path: 'ajustes',
    title: 'Ajustes',
    loadComponent: () => import('./settings/settings').then((m) => m.SettingsPage),
  },
  { path: '**', redirectTo: 'resumen' },
];
