import { provideZonelessChangeDetection, Type } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { beforeEach, describe, expect, it } from 'vitest';
import { CashflowStore } from './core/cashflow.store';
import { localeProviders } from './core/locale';
import { MemoryStorage } from './core/memory-storage';
import { STORAGE_BACKEND } from './core/storage.service';
import { AuditPage } from './audit/audit-page';
import { Dashboard } from './dashboard/dashboard';
import { MonthDetail } from './month/month-detail';
import { SettingsPage } from './settings/settings';
import { Shell } from './shell/shell';
import { routes } from './app.routes';

/** Render de humo: detecta errores de plantilla que el build no alcanza a ver. */
describe('render de las vistas', () => {
  let store: CashflowStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        ...localeProviders,
        provideRouter(routes),
        { provide: STORAGE_BACKEND, useValue: new MemoryStorage() },
      ],
    });
    store = TestBed.inject(CashflowStore);
    store.setBaseYear(2026);
    store.updateSettings({ openingBalance: 1_000_000 });
    store.setYear(2026);
    store.selectMonth('2026-01');
  });

  function render<T>(component: Type<T>): ComponentFixture<T> {
    const fixture = TestBed.createComponent(component);
    fixture.detectChanges();
    return fixture;
  }

  function seedMovements(): void {
    store.addRecurring({
      kind: 'expense',
      categoryId: 'cat-arriendo',
      description: 'Arriendo oficina',
      amount: 500_000,
      fromMonth: '2026-01',
      toMonth: null,
      interestAmount: null,
    });
    store.addRecurring({
      kind: 'income',
      categoryId: 'cat-ventas',
      description: 'Sueldo',
      amount: 1_200_000,
      fromMonth: '2026-01',
      toMonth: null,
      interestAmount: null,
    });
    store.addOneOff({
      kind: 'income',
      categoryId: 'cat-otros-ingresos',
      description: 'Bono',
      amount: 300_000,
      month: '2026-02',
      interestAmount: null,
    });
  }

  it('el shell monta la barra de navegación', () => {
    const text = render(Shell).nativeElement.textContent;
    expect(text).toContain('Flujo de Caja');
    expect(text).toContain('Resumen');
  });

  it('el resumen muestra el estado vacío sin movimientos', () => {
    const text = render(Dashboard).nativeElement.textContent;
    expect(text).toContain('Aún no hay movimientos');
  });

  it('el resumen muestra la matriz y los saldos arrastrados', () => {
    seedMovements();
    const element: HTMLElement = render(Dashboard).nativeElement;
    const text = element.textContent ?? '';
    expect(text).toContain('Saldo inicial');
    expect(text).toContain('Saldo final');
    expect(text).toContain('Arriendo');
    // Saldo final del primer mes: 1.000.000 + 1.200.000 − 500.000.
    expect(text).toContain('1.700.000');
    expect(element.querySelectorAll('.matrix tbody tr').length).toBeGreaterThan(4);
    expect(element.querySelector('app-balance-chart path.line')).not.toBeNull();
  });

  it('el resumen navega entre años y muestra el saldo arrastrado', async () => {
    seedMovements();
    const fixture = render(Dashboard);
    expect(fixture.nativeElement.textContent).toContain('Resumen 2026');

    // Cierre de 2026: 1.000.000 + 12 × 700.000 + 300.000 del bono de febrero.
    const cierre2026 = store.projection()[11].closingBalance;
    store.stepYear(1);
    await fixture.whenStable();
    fixture.detectChanges();

    const text = fixture.nativeElement.textContent ?? '';
    expect(text).toContain('Resumen 2027');
    expect(text).toContain('Saldo arrastrado de 2026');
    expect(store.yearOpeningBalance()).toBe(cierre2026);
  });

  it('el detalle mensual lista los movimientos del mes', () => {
    seedMovements();
    const element: HTMLElement = render(MonthDetail).nativeElement;
    const text = element.textContent ?? '';
    expect(text).toContain('Arriendo oficina');
    expect(text).toContain('Sueldo');
    expect(text).toContain('Saldo final');
    expect(text).toContain('1.700.000');
    // El bono es de febrero: no debe aparecer en enero.
    expect(text).not.toContain('Bono');
  });

  it('el detalle mensual marca las líneas ajustadas por override', () => {
    seedMovements();
    const arriendo = store.state().recurring[0];
    store.setOverride(arriendo.id, '2026-01', 400_000);
    const text = render(MonthDetail).nativeElement.textContent ?? '';
    expect(text).toContain('ajustado');
    expect(text).toContain('400.000');
  });

  it('la auditoría rinde las ocho preguntas con sus veredictos', () => {
    store.loadSample();
    store.setYear(store.baseYear());
    const element: HTMLElement = render(AuditPage).nativeElement;
    const text = element.textContent ?? '';

    expect(element.querySelectorAll('.check').length).toBe(8);
    expect(text).toContain('Punto crítico de caja');
    expect(text).toContain('Capacidad para asumir nuevos compromisos');
    expect(text).toContain('Fondo para imprevistos e impuestos');
    // Cada tarjeta trae su veredicto.
    expect(element.querySelectorAll('.check-pass').length).toBeGreaterThan(0);
    expect(element.querySelectorAll('.check-warn').length).toBeGreaterThan(0);
  });

  it('la auditoría avisa cuando no hay nada que auditar', () => {
    expect(render(AuditPage).nativeElement.textContent).toContain('Sin movimientos que auditar');
  });

  it('el resumen separa el resultado operacional del servicio de deuda', () => {
    store.loadSample();
    store.setYear(store.baseYear());
    const text = render(Dashboard).nativeElement.textContent ?? '';
    expect(text).toContain('Resultado operacional');
    expect(text).toContain('Servicio de deuda');
    expect(text).toContain('Impuestos provisionados');
    expect(text).toContain('Disponible real');
  });

  it('el resumen pinta el semáforo de cada mes', () => {
    store.loadSample();
    store.setYear(store.baseYear());
    const element: HTMLElement = render(Dashboard).nativeElement;

    expect(element.querySelectorAll('.matrix thead .dot-critical').length).toBe(2);
    expect(element.querySelectorAll('.matrix thead .dot-warning').length).toBe(7);
    expect(element.querySelectorAll('.matrix thead .dot-ok').length).toBe(3);
    expect(element.textContent).toContain('Meses con alerta');
    expect(element.querySelector('.highlight.alert-critical')).not.toBeNull();
  });

  it('el detalle mensual avisa cuando la plata no alcanza', async () => {
    store.loadSample();
    store.setYear(store.baseYear());
    store.selectMonth('2026-05');
    const fixture = render(MonthDetail);
    await fixture.whenStable();
    fixture.detectChanges();

    const banner = fixture.nativeElement.querySelector('.status-banner');
    expect(banner).not.toBeNull();
    expect(banner.classList).toContain('banner-critical');
    expect(banner.textContent).toContain('Cierra con saldo negativo');
  });

  it('un mes sano no muestra banner', async () => {
    store.loadSample();
    store.setYear(store.baseYear());
    store.selectMonth('2026-11');
    const fixture = render(MonthDetail);
    await fixture.whenStable();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.status-banner')).toBeNull();
  });

  it('la barra superior lleva el contador de alertas', async () => {
    store.loadSample();
    store.setYear(store.baseYear());
    const fixture = render(Shell);
    await fixture.whenStable();
    fixture.detectChanges();

    const badge = fixture.nativeElement.querySelector('.alert-badge');
    expect(badge).not.toBeNull();
    expect(badge.textContent.trim()).toBe('9');
    expect(badge.classList).toContain('badge-critical');
  });

  it('ajustes muestra el punto de partida y las categorías', () => {
    const text = render(SettingsPage).nativeElement.textContent ?? '';
    expect(text).toContain('Punto de partida');
    expect(text).toContain('Provisiones');
    expect(text).toContain('Respaldo');
    expect(text).toContain('Ingresos');
  });
});
