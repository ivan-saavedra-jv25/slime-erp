# Flujo de Caja

Mini-app de flujo de caja mensual. Angular standalone, sin backend: los datos viven en el
`localStorage` del navegador.

## Concepto

1. Se elige el **año base** y el **saldo inicial** de su enero. Cada vista cubre enero a diciembre.
2. Cada mes registra **ingresos** y **gastos** al detalle, agrupados por categoría.
3. Un movimiento puede ser **puntual** (un mes) o **recurrente** (arriendo, sueldos), con vigencia
   `desde` / `hasta`. Cada categoría define su **naturaleza** (operacional, no operacional,
   financiamiento) y, en gastos, si es **fijo o variable**. Las cuotas de préstamo separan capital
   de interés.
4. Un recurrente se puede **ajustar u omitir en un mes específico** sin cortar la serie.
5. `saldo final = saldo inicial + ingresos − gastos`. El saldo final de un mes es el **saldo
   inicial del mes siguiente**, y el cierre de diciembre es el saldo inicial de enero del año
   siguiente. El año se cambia con las flechas del Resumen o del detalle mensual.

## Semáforo

Cada mes tiene un estado (`core/health.ts`): **rojo** cuando el saldo no alcanza — cierra negativo,
o queda bajo los impuestos ya provisionados; **ámbar** cuando se gasta más de lo que entra o el
disponible cae bajo el colchón; **verde** el resto. Se ve como punto en cada mes del Resumen,
como banner con el motivo en el detalle mensual, y como contador en la pestaña Auditoría. El color
nunca va solo: siempre lo acompaña el texto del motivo.

## Auditoría

La pestaña **Auditoría** responde ocho preguntas sobre el flujo del año: si algún mes cierra en
rojo, cuál es el punto crítico por saldo y por resultado, qué parte de los ingresos no viene del
giro, cuán rígida es la estructura de gastos, si hay provisiones, cuánta cuota mensual nueva
aguanta el flujo y qué pasa con el excedente. Cada tarjeta trae criterio, hallazgo con montos y
recomendación.

Las **provisiones** se configuran en Ajustes: un % de impuestos sobre el resultado operacional
positivo, que se descuenta del disponible por ser plata ajena, y un colchón de N meses de gastos
fijos recurrentes, que se compara contra el disponible sin descontarlo.

## Flujo de ejemplo

**Ajustes → Respaldo → Cargar ejemplo** (o el botón del estado vacío del Resumen) carga una
empresa chica: ventas mensuales de $8.000.000, sueldos por $2.600.000, arriendo de $450.000,
servicios por $220.000 y una cuota de crédito de $620.000 (con $180.000 de interés), más patente
municipal, aguinaldos y una venta de activo. Febrero trae un ajuste de un solo mes sobre las
ventas, para ver cómo funciona el override. Trae provisiones de 27% de impuestos y dos meses de
colchón.

## Comandos

```bash
npm start    # servidor de desarrollo en http://localhost:4200
npm test     # tests unitarios (vitest)
npm run build
```

## Estructura

| Ruta | Contenido |
|---|---|
| `src/app/core/projection.ts` | Motor de cálculo: funciones puras, sin dependencias de Angular |
| `src/app/core/audit.ts` | Las ocho verificaciones de la auditoría, también funciones puras |
| `src/app/core/cashflow.store.ts` | Estado con signals + persistencia automática |
| `src/app/core/storage.service.ts` | `localStorage`, validación y respaldo JSON |
| `src/app/core/migrate.ts` | Migración de estados guardados con versiones anteriores |
| `src/app/dashboard/` | Resumen anual: matriz meses × categorías y gráfico del saldo |
| `src/app/audit/` | Panel de auditoría del año |
| `src/app/month/` | Detalle mensual, diálogo de movimientos y de ajuste por mes |
| `src/app/settings/` | Año base, saldo inicial, categorías, provisiones, export/import |

## Respaldo

Los datos se guardan sólo en este navegador. En **Ajustes → Respaldo** se exporta e importa un
JSON con todo el flujo.
